/*
 * campaign_main.c -- ML-DSA-44 rejection-path campaign on ESP32.
 *
 * One boot block per run. The host resets the device between blocks and
 * passes the block index in via CAMPAIGN_BLOCK.
 *
 * Per invocation:
 *   1. arm the fixture RNG for this invocation index
 *   2. start timer, call the ordinary signing API, stop timer
 *   3. verify the signature on-device, AFTER the stop timestamp
 *   4. emit one CSV record with timings, counters, return code and status
 *
 * The timed interval spans the signing API only. Fixture selection, arming,
 * verification and printing are all outside it.
 */
#include <stdio.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_timer.h"
#include "esp_system.h"
#include "esp_mac.h"
#include "esp_clk_tree.h"
#include "esp_heap_caps.h"

#include "api.h"
#include "fixture_rng.h"
#include "mldsa_counters.h"
#include "mldsa_stages.h"
#include "campaign_config.h"

#define PK_BYTES   PQCLEAN_MLDSA44_CLEAN_CRYPTO_PUBLICKEYBYTES
#define SK_BYTES   PQCLEAN_MLDSA44_CLEAN_CRYPTO_SECRETKEYBYTES
#define SIG_BYTES  PQCLEAN_MLDSA44_CLEAN_CRYPTO_BYTES

/* Fixtures embedded in flash by main/CMakeLists.txt. */
extern const uint8_t sk_start[]   asm("_binary_secret_keys_bin_start");
extern const uint8_t pk_start[]   asm("_binary_public_keys_bin_start");
extern const uint8_t msg_start[]  asm("_binary_messages_bin_start");
extern const uint8_t sched_start[] asm("_binary_schedule_table_bin_start");
extern const uint8_t sched_end[]   asm("_binary_schedule_table_bin_end");
extern const uint8_t seed_start[]  asm("_binary_master_seed_bin_start");

static uint8_t sig[SIG_BYTES];

#ifdef MLDSA_STAGE_TRACE
/* The stage clock must be the same source as the outer timer, so checkpoint
 * offsets and whole-call durations are directly comparable. */
static int64_t stage_now(void) { return esp_timer_get_time(); }
#endif

static void emit_header(void) {
    printf("run_schema,2\n");
    printf("invocation_id,block,key_id,message_id,rand_index,"
           "start_us,end_us,elapsed_us,K,reject_z,reject_w0,reject_ct0,"
           "reject_hint,sign_rc,verify_rc,siglen,rng_ok,k_ok\n");
}

static void banner(void) {
    uint8_t mac[6];
    esp_read_mac(mac, ESP_MAC_WIFI_STA);
    uint32_t hz = 0;
    esp_clk_tree_src_get_freq_hz(SOC_MOD_CLK_CPU,
                                 ESP_CLK_TREE_SRC_FREQ_PRECISION_CACHED, &hz);

    printf("#\n# ML-DSA-44 campaign, variant %s\n", CAMPAIGN_VARIANT_NAME);
    printf("# Device MAC: %02X:%02X:%02X:%02X:%02X:%02X\n",
           mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
    printf("# CPU: %u Hz | core %d | prio %d\n",
           (unsigned)hz, CAMPAIGN_CORE, CAMPAIGN_PRIO);
    printf("# Build: %s %s | gcc %s\n", __DATE__, __TIME__, __VERSION__);
    printf("# Block: %d of %d | invocations this run: %d of %d\n",
           CAMPAIGN_BLOCK, CAMPAIGN_N_BLOCKS, CAMPAIGN_N, CAMPAIGN_PER_BLOCK);
    printf("# Schedule table: %u bytes\n", (unsigned)(sched_end - sched_start));
    printf("# Msg bytes: %d | timer: esp_timer_get_time (1 us)\n", CAMPAIGN_MSG_BYTES);
    printf("# Internal RAM free: %u B, largest block: %u B\n",
           (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL),
           (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL));
    printf("#\n");
}

static void campaign_task(void *arg) {
    (void)arg;
    fixture_rng_init(seed_start);
#ifdef MLDSA_STAGE_TRACE
    mldsa_stage_clock = stage_now;
    printf("# stage trace enabled, buffer %d events per invocation\n",
           MLDSA_STAGE_CAP);
#endif

    /* Warmup signatures are labelled separately and excluded from the target
     * count; they are not written as campaign records. */
    for (int w = 0; w < CAMPAIGN_WARMUP; w++) {
        size_t siglen = 0;
        uint32_t idx = (uint32_t)(CAMPAIGN_WARMUP_BASE + w);
        fixture_rng_arm(idx);
        PQCLEAN_MLDSA44_CLEAN_crypto_sign_signature(
            sig, &siglen, msg_start, CAMPAIGN_MSG_BYTES, sk_start);
    }
    printf("# Warmup complete: %d signatures (not counted)\n", CAMPAIGN_WARMUP);

#ifdef MLDSA_STAGE_TRACE
    printf("stage_schema,1\n");
    printf("# STAGE,invocation,candidate,label,t_us,overflow\n");
#endif
    emit_header();

    const int base = CAMPAIGN_BLOCK * CAMPAIGN_PER_BLOCK;
    uint32_t bad_k = 0, bad_verify = 0, bad_sign = 0, bad_rng = 0;

    for (int i = 0; i < CAMPAIGN_N; i++) {
        const int inv = base + i;
        const uint8_t entry = sched_start[inv];
        const int key = entry >> 4, msg = entry & 0x0f;
        const uint8_t *sk = sk_start + (size_t)key * SK_BYTES;
        const uint8_t *pk = pk_start + (size_t)key * PK_BYTES;
        const uint8_t *m  = msg_start + (size_t)msg * CAMPAIGN_MSG_BYTES;

        size_t siglen = 0;
        MLDSA_COUNT_RESET();
#ifdef MLDSA_STAGE_TRACE
        mldsa_stage_reset();
#endif
        fixture_rng_arm((uint32_t)inv);

        /* --- timed interval: the ordinary signing API only --------------- */
        const int64_t t0 = esp_timer_get_time();
        const int rc = PQCLEAN_MLDSA44_CLEAN_crypto_sign_signature(
            sig, &siglen, m, CAMPAIGN_MSG_BYTES, sk);
        const int64_t t1 = esp_timer_get_time();
        /* ----------------------------------------------------------------- */

        /* Every timed signature is verified, after the stop timestamp. */
        const int vrc = PQCLEAN_MLDSA44_CLEAN_crypto_sign_verify(
            sig, siglen, m, CAMPAIGN_MSG_BYTES, pk);

        const int rng_ok = fixture_rng_consumed_exactly_once();
#ifdef MLDSA_COUNT_EXITS
        const mldsa_counters_t c = mldsa_counters;
        const int k_ok = mldsa_counters_consistent(&c);
#else
        /* plain build carries no counters: emit zeros and k_ok = -1 */
        const mldsa_counters_t c = (mldsa_counters_t){0};
        const int k_ok = -1;
#endif
        if (rc != 0)  bad_sign++;
        if (vrc != 0) bad_verify++;
        if (!rng_ok)  bad_rng++;
        if (k_ok == 0) bad_k++;

#ifdef MLDSA_STAGE_TRACE
        /* Emitted after the timed interval, so printing cannot perturb it.
         * A separate section keeps the main record schema unchanged. */
        for (uint16_t e = 0; e < mldsa_stage_n; e++) {
            const mldsa_stage_event *ev = &mldsa_stage_buf[e];
            printf("STAGE,%d,%u,%u,%lld,%u\n", inv,
                   (unsigned)ev->candidate, (unsigned)ev->label,
                   (long long)ev->t_us, (unsigned)mldsa_stage_overflow);
        }
#endif
        printf("%d,%d,%d,%d,%d,%lld,%lld,%lld,%u,%u,%u,%u,%u,%d,%d,%u,%d,%d\n",
               inv, CAMPAIGN_BLOCK, key, msg, inv,
               (long long)t0, (long long)t1, (long long)(t1 - t0),
               (unsigned)c.iterations, (unsigned)c.reject_z,
               (unsigned)c.reject_w0, (unsigned)c.reject_ct0,
               (unsigned)c.reject_hint,
               rc, vrc, (unsigned)siglen, rng_ok, k_ok);
    }

    printf("# Faults: sign_rc=%u verify=%u rng=%u k_identity=%u rng_internal=%u\n",
           (unsigned)bad_sign, (unsigned)bad_verify, (unsigned)bad_rng,
           (unsigned)bad_k, (unsigned)fixture_rng_fault_count());
    printf("# Stack high water: %u bytes free\n",
           (unsigned)uxTaskGetStackHighWaterMark(NULL));
    printf("# === campaign block %d complete ===\n", CAMPAIGN_BLOCK);
    vTaskDelete(NULL);
}

void app_main(void) {
    vTaskDelay(pdMS_TO_TICKS(2000));   /* let USB CDC settle before output */
    banner();
    xTaskCreatePinnedToCore(campaign_task, "campaign", CAMPAIGN_STACK,
                            NULL, CAMPAIGN_PRIO, NULL, CAMPAIGN_CORE);
}
