#ifndef TELEMETRY_CONFIG_H
#define TELEMETRY_CONFIG_H

#define TEL_ACQ_PERIOD_US   10000        /* 10 ms acquisition schedule       */
#define TEL_ACQ_DEADLINE_US 10000        /* completion deadline after release */
#define TEL_MSG_BYTES       128
#define TEL_N_FIXTURES      64

/* One common key per replicate, different keys between replicates
 * (MAIN2_EXPERIMENTS section 6). Paired across architectures. */
#ifndef TEL_KEY
#define TEL_KEY             0
#endif
#define TEL_RND_BASE        2000000u     /* clear of campaign indices        */
#define TEL_DRAIN_US        (30 * 1000000LL)

/* 1 = release no reports at all, for a true acquisition-only baseline. */
/* 1 = fresh-input policy: every request derives its own message and signing
 * randomness (see components/pqcrypto_fx/fresh_fixture.h); fixture_id == request id. */
#ifndef TEL_FRESH
#define TEL_FRESH           0
#endif

#ifndef TEL_NO_SIGNING
#define TEL_NO_SIGNING      0
#endif

#ifndef TEL_WORKER
#define TEL_WORKER          0            /* 0 inline, 1 worker_core          */
#endif
#ifndef TEL_REPORT_PERIOD_US
#define TEL_REPORT_PERIOD_US 1000000     /* 100000 | 250000 | 1000000        */
#endif
#ifndef TEL_RUN_SECONDS
#define TEL_RUN_SECONDS     600
#endif
#define TEL_RUN_US          ((int64_t)TEL_RUN_SECONDS * 1000000LL)

/* Calibrated once with no signing, then frozen. Measured duration is
 * reported rather than assumed to be exactly 100 us. */
#ifndef TEL_ACQ_ITERS
#define TEL_ACQ_ITERS       4000
#endif

/* Acquisition keeps its core; the signer runs on the other one. Priorities
 * are recorded in the banner. */
/* Only the signing task needs the big stack. */
#if TEL_WORKER
#define TEL_RUN_STACK       (8 * 1024)
#define TEL_SIGNER_STACK    (80 * 1024)
#else
#define TEL_RUN_STACK       (80 * 1024)
#define TEL_SIGNER_STACK    (8 * 1024)
#endif

#define TEL_ACQ_CORE        0
#define TEL_ACQ_PRIO        6
#define TEL_SIGNER_CORE     1
#define TEL_SIGNER_PRIO     5

/* RAM ring sizes: a 600 s run at 100 ms releases yields 6,000 reports and
 * 60,000 acquisitions. Overflow is counted and printed, never silent. */
#define TEL_MAX_REPORTS     6200      /* 12 bytes each -> ~74 KB          */
#define TEL_MAX_ACQ_EXC     1000      /* bounded diagnostic sample of late
                                       * and skipped releases, ~16 KB. Halved
                                       * to make room for the per-report
                                       * signature digests, which are real
                                       * validation; this ring is only a
                                       * sample and the exact totals come
                                       * from the counters.               */

#endif /* TELEMETRY_CONFIG_H */
