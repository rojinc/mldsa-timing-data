#ifndef CAMPAIGN_CONFIG_H
#define CAMPAIGN_CONFIG_H

/* Matches tools/make_schedule.py: 10 keys x 5 messages x 200 x 5 blocks. */
#define CAMPAIGN_N_BLOCKS     5
#define CAMPAIGN_PER_BLOCK    10000
#define CAMPAIGN_MSG_BYTES    128

/* Warmups run after each real reset, are labelled separately and do not
 * count toward the target. Their indices sit far above the campaign range so
 * they can never collide with a real invocation's randomness. */
#define CAMPAIGN_WARMUP       100
#define CAMPAIGN_WARMUP_BASE  1000000

#define CAMPAIGN_CORE         1
#define CAMPAIGN_PRIO         5
#define CAMPAIGN_STACK        (100 * 1024)

#ifndef CAMPAIGN_BLOCK
#define CAMPAIGN_BLOCK        0
#endif

/* Pilot runs use a prefix of the block. CAMPAIGN_LIMIT=0 means the full
 * block. The fixtures used are the block's first N, so a plain and a counts
 * pilot see byte-identical inputs. */
#ifndef CAMPAIGN_LIMIT
#define CAMPAIGN_LIMIT        0
#endif
#define CAMPAIGN_N  ((CAMPAIGN_LIMIT > 0 && CAMPAIGN_LIMIT < CAMPAIGN_PER_BLOCK) \
                     ? CAMPAIGN_LIMIT : CAMPAIGN_PER_BLOCK)

#endif /* CAMPAIGN_CONFIG_H */
