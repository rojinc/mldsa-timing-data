/*
 * telemetry_main.c -- ESP32 acquisition-vs-signing experiment.
 *
 * Two architectures, identical workload, key, fixture policy and queue:
 *   inline       acquisition and signing share one task on one core, so a
 *                signature delays foreground acquisition
 *   worker_core  acquisition stays on its core, a signing worker runs on the
 *                other core
 *
 * Acquisition is released every 10,000 us from a monotonic schedule with a
 * 10,000 us completion deadline. If acquisition falls behind, the latest due
 * sample runs and older unserved releases are counted as skipped -- no burst
 * of catch-up samples is reported as timely acquisition.
 *
 * Reports are released at a fixed period; the signature-ready deadline equals
 * that period. Releases are scheduled from the run origin even while the
 * signer is busy, so a request records its intended release regardless of
 * when it is processed. Queue: 8 pending + 1 running, drop-new.
 *
 * Nothing blocks on serial inside acquisition or signing: records go to a RAM
 * ring and are drained after the measured window.
 */
#include <stdio.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_timer.h"
#include "esp_mac.h"
#include "esp_heap_caps.h"

#include "api.h"
#include "fips202.h"   /* shake256 for the per-report digest */
#include "fixture_rng.h"
#include "fresh_fixture.h"
#include "report_queue.h"
#include "telemetry_config.h"

#define SIG_BYTES PQCLEAN_MLDSA44_CLEAN_CRYPTO_BYTES
#define SK_BYTES  PQCLEAN_MLDSA44_CLEAN_CRYPTO_SECRETKEYBYTES

extern const uint8_t sk_start[]  asm("_binary_secret_keys_bin_start");
extern const uint8_t msg_start[] asm("_binary_messages_bin_start");
extern const uint8_t seed_start[] asm("_binary_master_seed_bin_start");

/* ---- bounded, nonblocking logging -------------------------------------

 * A 600 s run releases 60,000 acquisitions and up to 6,000 reports. Full
 * 64-bit records for those would need about 2.2 MB, against roughly 320 KB of
 * internal RAM, so the logs are compact:
 *
 *   reports       12 bytes each; intended release is implicit in the index,
 *                 and the two timestamps are stored as unsigned offsets from
 *                 it (a response longer than 71 minutes cannot occur here)
 *   acquisitions  counters plus histograms for the whole population, with a
 *                 bounded ring of full records for late and skipped releases,
 *                 which are the ones worth inspecting individually
 *
 * Nothing here blocks; serial output happens only after the measured window.
 */

typedef struct {
    uint32_t started_off;     /* us after intended release, UINT32_MAX = none */
    uint32_t ready_off;
    uint8_t  digest[8];       /* SHAKE256 of the signature, checked on host */
    uint16_t siglen;
    int8_t   sign_rc;
    uint8_t  queue_depth;
    uint8_t  status;          /* 0 done, 1 dropped, 2 censored */
} rep_rec;

typedef struct {
    uint32_t index;
    uint32_t start_off;       /* us after intended release */
    uint32_t duration;        /* us of acquisition work */
    uint8_t  skipped;
} acq_exc;

#define NO_OFF 0xFFFFFFFFu
#define HIST_BUCKETS 32
#define HIST_US_PER_BUCKET 500      /* 0..16 ms in 500 us steps, last = overflow */

static rep_rec rep_log[TEL_MAX_REPORTS];
static acq_exc acq_exc_log[TEL_MAX_ACQ_EXC];
static uint32_t hist_start[HIST_BUCKETS], hist_complete[HIST_BUCKETS];
static volatile uint32_t rep_n, acq_exc_n, rep_overflow, acq_exc_overflow;
static volatile uint32_t acq_total, acq_on_time, acq_late, acq_skipped;

static void hist_add(uint32_t *h, int64_t us) {
    if (us < 0) { us = 0; }
    uint32_t b = (uint32_t)(us / HIST_US_PER_BUCKET);
    h[b < HIST_BUCKETS ? b : HIST_BUCKETS - 1]++;
}

/* ---- deterministic emulated acquisition work --------------------------- */

static volatile uint32_t acq_checksum;

/* Compiler-visible: the checksum is published, so the loop cannot be elided.
 * TEL_ACQ_ITERS is calibrated once in a no-signing run and then frozen. */
static uint32_t acquire_work(uint32_t seed) {
    uint32_t x = seed;
    for (uint32_t i = 0; i < TEL_ACQ_ITERS; i++) {
        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    }
    return x;
}

/* ---- shared state ------------------------------------------------------ */

static report_queue q;
static portMUX_TYPE q_lock = portMUX_INITIALIZER_UNLOCKED;
static SemaphoreHandle_t work_ready;
static int64_t origin_us;
static volatile int running_flag = 1;
static volatile int64_t signer_available_us;
static uint8_t sig[SIG_BYTES];

static void log_report(uint32_t id, int64_t rel, int64_t st_abs, int64_t rdy_abs,
                       int depth, uint8_t status,
                       const uint8_t digest[8], int rc, uint16_t siglen) {
    /* Indexed by request id: releases are dense from the run origin, so the
     * index carries the intended release and no id field is needed. */
    if (id >= TEL_MAX_REPORTS) { rep_overflow++; return; }
    rep_rec *r = &rep_log[id];
    r->started_off = (st_abs < 0) ? NO_OFF
                                  : (uint32_t)((st_abs - origin_us) - rel);
    r->ready_off   = (rdy_abs < 0) ? NO_OFF
                                   : (uint32_t)((rdy_abs - origin_us) - rel);
    r->queue_depth = (uint8_t)(depth > 255 ? 255 : depth);
    r->status = status;
    r->sign_rc = (int8_t)rc;
    r->siglen = siglen;
    if (digest) { memcpy(r->digest, digest, 8); }
    if (id + 1 > rep_n) { rep_n = id + 1; }
}

/* One signature, timed. Returns signature-ready time. */
/* Signs one report and digests its output.
 *
 * The digest is a real SHAKE256 over the whole signature, taken AFTER the
 * signature-ready timestamp, and stored so the host can compare it with the
 * expected digest for that fixture offline. Sending 2.4 KB signatures over
 * UART inside the measured window would dominate the report deadline, which
 * is why only 8 bytes per report are kept.
 *
 * Digesting and logging are post-signature work: they delay the next job, so
 * they are charged to signer-available, not to signature-ready.
 */
#if TEL_FRESH
/* Fresh-input policy: the message of the request is derived here, before the
 * start timestamp is taken, so the derivation (one SHAKE256 call) is charged to
 * dispatch, as fixture preparation is on the RP2040, not to signing. */
static uint8_t fresh_msg[FRESH_MSG_BYTES];
static void prepare_request(const rq_item *it) {
    fresh_message(seed_start, FRESH_INDEX(TEL_KEY, it->fixture_id), fresh_msg);
}
#else
static void prepare_request(const rq_item *it) { (void)it; }
#endif

static int64_t sign_one(const rq_item *it, uint8_t out_digest[8],
                        int *out_rc, uint16_t *out_len) {
#if TEL_FRESH
    fixture_rng_arm(FRESH_INDEX(TEL_KEY, it->fixture_id));
    const uint8_t *msg = fresh_msg;
#else
    fixture_rng_arm(TEL_RND_BASE + it->fixture_id);
    const uint8_t *msg = msg_start;
#endif
    size_t len = 0;
    int rc = PQCLEAN_MLDSA44_CLEAN_crypto_sign_signature(
        sig, &len, msg, TEL_MSG_BYTES,
        sk_start + (size_t)TEL_KEY * SK_BYTES);
    int64_t ready = esp_timer_get_time();

    uint8_t dg[8];
    shake256(dg, sizeof dg, sig, len);
    memcpy(out_digest, dg, sizeof dg);
    *out_rc = rc;
    *out_len = (uint16_t)len;
    acq_checksum += dg[0];

    signer_available_us = esp_timer_get_time();
    return ready;
}

/* ---- worker task: only used by the worker_core architecture ------------ */

static void signer_task(void *arg) {
    (void)arg;
    while (running_flag) {
        if (xSemaphoreTake(work_ready, pdMS_TO_TICKS(100)) != pdTRUE) { continue; }
        rq_item it;
        int depth;
        portENTER_CRITICAL(&q_lock);
        int got = rq_take(&q, &it);
        depth = rq_pending(&q);
        portEXIT_CRITICAL(&q_lock);
        if (!got) { continue; }
        uint8_t dg[8]; int rc; uint16_t sl;
        prepare_request(&it);
        int64_t start = esp_timer_get_time();
        int64_t ready = sign_one(&it, dg, &rc, &sl);
        portENTER_CRITICAL(&q_lock);
        rq_complete(&q);
        portEXIT_CRITICAL(&q_lock);
        log_report(it.request_id, it.released_us, start, ready, depth, 0, dg, rc, sl);
    }
    vTaskDelete(NULL);
}

/* ---- main loop: acquisition schedule plus report releases --------------- */

static void run_task(void *arg) {
    (void)arg;
    fixture_rng_init(seed_start);
    rq_init(&q);
    origin_us = esp_timer_get_time();

    uint32_t next_acq = 0, next_rep = 0, req_id = 0;
    const int64_t acq_period = TEL_ACQ_PERIOD_US;
    const int64_t rep_period = TEL_REPORT_PERIOD_US;

    while (1) {
        int64_t now = esp_timer_get_time() - origin_us;
        if (now >= TEL_RUN_US) { break; }

        /* Report releases are scheduled from the origin, including while the
         * signer is busy, so intended release never drifts.
         * TEL_NO_SIGNING gives a genuine acquisition-only baseline: no report
         * is ever released, so no signature runs at all. Using a very long
         * report period instead still fires one signature at t=0, which was
         * enough to cause 6 acquisition skips in the first attempt. */
        while (!TEL_NO_SIGNING && (int64_t)next_rep * rep_period <= now) {
            int64_t rel = (int64_t)next_rep * rep_period;
            portENTER_CRITICAL(&q_lock);
            int ok = rq_offer(&q, req_id, TEL_FRESH ? req_id : req_id % TEL_N_FIXTURES, rel);
            int depth = rq_pending(&q);
            portEXIT_CRITICAL(&q_lock);
            if (!ok) {
                log_report(req_id, rel, -1, -1, depth, 1, NULL, 0, 0); /* dropped */
            } else if (TEL_WORKER) {
                xSemaphoreGive(work_ready);
            }
            req_id++; next_rep++;
        }

        /* Acquisition: run the latest due release, count older ones skipped. */
        int64_t due = now / acq_period;
        if ((int64_t)next_acq <= due) {
            while ((int64_t)next_acq < due) {
                acq_total++; acq_skipped++;
                if (acq_exc_n < TEL_MAX_ACQ_EXC) {
                    acq_exc *a = &acq_exc_log[acq_exc_n++];
                    a->index = next_acq; a->start_off = NO_OFF;
                    a->duration = 0; a->skipped = 1;
                } else { acq_exc_overflow++; }
                next_acq++;
            }
            int64_t intended = (int64_t)next_acq * acq_period;
            int64_t st = esp_timer_get_time() - origin_us;
            acq_checksum += acquire_work((uint32_t)next_acq);
            int64_t fi = esp_timer_get_time() - origin_us;
            acq_total++;
            const int64_t jitter = st - intended;
            const int64_t response = fi - intended;
            hist_add(hist_start, jitter);
            hist_add(hist_complete, response);
            if (response <= TEL_ACQ_DEADLINE_US) {
                acq_on_time++;
            } else {
                acq_late++;
                if (acq_exc_n < TEL_MAX_ACQ_EXC) {
                    acq_exc *a = &acq_exc_log[acq_exc_n++];
                    a->index = next_acq;
                    a->start_off = (uint32_t)(jitter < 0 ? 0 : jitter);
                    a->duration = (uint32_t)(fi - st);
                    a->skipped = 0;
                } else { acq_exc_overflow++; }
            }
            next_acq++;
        }

        /* Inline architecture signs on this same task, so a signature blocks
         * the next acquisition. That is the effect under study. */
        if (!TEL_WORKER) {
            rq_item it;
            int depth;
            portENTER_CRITICAL(&q_lock);
            int got = rq_take(&q, &it);
            depth = rq_pending(&q);
            portEXIT_CRITICAL(&q_lock);
            if (got) {
                uint8_t dg[8]; int rc; uint16_t sl;
                prepare_request(&it);
                int64_t start = esp_timer_get_time();
                int64_t ready = sign_one(&it, dg, &rc, &sl);
                portENTER_CRITICAL(&q_lock);
                rq_complete(&q);
                portEXIT_CRITICAL(&q_lock);
                log_report(it.request_id, it.released_us, start, ready, depth, 0, dg, rc, sl);
            }
        }
    }

    /* Stop new releases, then drain what was already admitted. Anything still
     * pending or running when the drain window ends is censored, not dropped
     * from the denominator. */
    int64_t drain_start = esp_timer_get_time();
    while (esp_timer_get_time() - drain_start < TEL_DRAIN_US) {
        rq_item it;
        portENTER_CRITICAL(&q_lock);
        int got = TEL_WORKER ? 0 : rq_take(&q, &it);
        int left = rq_pending(&q) + q.running;
        portEXIT_CRITICAL(&q_lock);
        if (!TEL_WORKER && got) {
            uint8_t dg[8]; int rc; uint16_t sl;
            prepare_request(&it);
            int64_t start = esp_timer_get_time();
            int64_t ready = sign_one(&it, dg, &rc, &sl);
            portENTER_CRITICAL(&q_lock);
            rq_complete(&q);
            portEXIT_CRITICAL(&q_lock);
            log_report(it.request_id, it.released_us, start, ready, 0, 0, dg, rc, sl);
        } else if (left == 0) {
            break;
        } else {
            vTaskDelay(1);
        }
    }
    running_flag = 0;
    vTaskDelay(pdMS_TO_TICKS(200));

    portENTER_CRITICAL(&q_lock);
    int censored = rq_pending(&q) + q.running;
    report_queue snap = q;
    portEXIT_CRITICAL(&q_lock);

    printf("# checksum: %u\n", (unsigned)acq_checksum);
    printf("# queue: admitted=%u dropped=%u completed=%u max_occupancy=%d "
           "censored=%d\n", (unsigned)snap.admitted, (unsigned)snap.dropped,
           (unsigned)snap.completed, snap.max_occupancy, censored);
    printf("# releases: reports=%u acquisitions=%u\n",
           (unsigned)req_id, (unsigned)next_acq);
    printf("# acquisition: total=%u on_time=%u late=%u skipped=%u "
           "deadline_failures=%u\n", (unsigned)acq_total, (unsigned)acq_on_time,
           (unsigned)acq_late, (unsigned)acq_skipped,
           (unsigned)(acq_late + acq_skipped));
    printf("# log overflow: reports=%u acq_exceptions=%u\n",
           (unsigned)rep_overflow, (unsigned)acq_exc_overflow);

    printf("hist_bucket_us,start_jitter,completion_response\n");
    for (int i = 0; i < HIST_BUCKETS; i++) {
        printf("%d,%u,%u\n", i * HIST_US_PER_BUCKET,
               (unsigned)hist_start[i], (unsigned)hist_complete[i]);
    }
    printf("acq_index,start_off_us,duration_us,skipped\n");
    for (uint32_t i = 0; i < acq_exc_n; i++) {
        acq_exc *a = &acq_exc_log[i];
        printf("%u,%d,%u,%u\n", (unsigned)a->index,
               a->start_off == NO_OFF ? -1 : (int)a->start_off,
               (unsigned)a->duration, a->skipped);
    }
    printf("rep_id,released_us,started_off_us,ready_off_us,queue_depth,status,"
           "fixture_id,sign_rc,siglen,digest\n");
    for (uint32_t i = 0; i < rep_n; i++) {
        rep_rec *r = &rep_log[i];
        printf("%u,%lld,%d,%d,%u,%u,%u,%d,%u,", (unsigned)i,
               (long long)((int64_t)i * rep_period),
               r->started_off == NO_OFF ? -1 : (int)r->started_off,
               r->ready_off == NO_OFF ? -1 : (int)r->ready_off,
               r->queue_depth, r->status,
               (unsigned)(TEL_FRESH ? i : i % TEL_N_FIXTURES), (int)r->sign_rc,
               (unsigned)r->siglen);
        for (int b = 0; b < 8; b++) { printf("%02x", r->digest[b]); }
        printf("\n");
    }
    printf("# stack high water: run task %u bytes free\n",
           (unsigned)uxTaskGetStackHighWaterMark(NULL));
    printf("# === telemetry run complete ===\n");
    vTaskDelete(NULL);
}

void app_main(void) {
    uint8_t mac[6];
    vTaskDelay(pdMS_TO_TICKS(2000));
    esp_read_mac(mac, ESP_MAC_WIFI_STA);
    printf("#\n# ML-DSA-44 telemetry, architecture %s\n",
           TEL_WORKER ? "worker_core" : "inline");
    printf("# Device MAC: %02X:%02X:%02X:%02X:%02X:%02X\n",
           mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
    printf("# report period: %d us | acq period: %d us | run: %lld us\n",
           TEL_REPORT_PERIOD_US, TEL_ACQ_PERIOD_US, (long long)TEL_RUN_US);
    printf("# acq work iters: %d (frozen) | queue: %d pending + 1 running\n",
           TEL_ACQ_ITERS, RQ_PENDING_CAPACITY);
    printf("# signing key: %d | fixture ids paired across architectures\n", TEL_KEY);
    printf("# fixture policy: %s\n", TEL_FRESH
           ? "fresh (message and randomness derived per request, fixture_id = request id)"
           : "64 fixtures per replicate");
    printf("# signing enabled: %s\n", TEL_NO_SIGNING ? "no (acquisition-only baseline)" : "yes");
    printf("# Build: %s %s | gcc %s\n#\n", __DATE__, __TIME__, __VERSION__);

    /* Measure the emulated acquisition work directly. The 500 us histogram
     * buckets cannot resolve a ~100 us job, and the plan requires the
     * measured duration to be reported rather than assumed. */
    {
        volatile uint32_t sink = 0;
        int64_t c0 = esp_timer_get_time();
        for (int i = 0; i < 200; i++) { sink += acquire_work((uint32_t)i); }
        int64_t c1 = esp_timer_get_time();
        acq_checksum += sink;
        printf("# acq work measured: %lld ns per job over 200 reps "
               "(target 100000 ns)\n", (long long)((c1 - c0) * 1000 / 200));
    }

    work_ready = xSemaphoreCreateCounting(64, 0);
    /* Whichever task signs needs the full ML-DSA-44 signing stack (measured
     * high water 52 KB in the campaign runs); the other one only schedules.
     * Sizing both large would exhaust internal RAM alongside the logs. */
    if (TEL_WORKER) {
        xTaskCreatePinnedToCore(signer_task, "signer", TEL_SIGNER_STACK, NULL,
                                TEL_SIGNER_PRIO, NULL, TEL_SIGNER_CORE);
    }
    xTaskCreatePinnedToCore(run_task, "run", TEL_RUN_STACK, NULL,
                            TEL_ACQ_PRIO, NULL, TEL_ACQ_CORE);
}
