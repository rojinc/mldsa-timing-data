/*
 * fresh_fixture.h -- fresh-input policy for the telemetry runs.
 *
 * With TEL_FRESH=1 every report request i of a run with signing key k uses
 * its own signing randomness and its own message:
 *
 *   index      = FRESH_INDEX(k, i) = 3,000,000 + 10,000 k + i
 *   randomness = SHAKE256(master_seed || uint32_le(index))[0:32]   (fixture_rng)
 *   message    = SHAKE256(master_seed || uint32_le(index) || "RPT")[0:128]
 *
 * The index range starts at 3,000,000, clear of the campaign indices
 * (< 50,000) and of the fixed-fixture telemetry range (2,000,000-2,000,063),
 * so no randomness is ever reused between experiments. The host generator
 * (fixtures/gen/telemetry_expected_fresh.c) includes this same header, so the
 * device and the host derive identical inputs by construction.
 */
#ifndef FRESH_FIXTURE_H
#define FRESH_FIXTURE_H

#include <stdint.h>
#include <string.h>
#include "fips202.h"

#define FRESH_INDEX_BASE 3000000u
#define FRESH_MSG_BYTES  128
#define FRESH_INDEX(key, id) (FRESH_INDEX_BASE + (uint32_t)(key) * 10000u + (uint32_t)(id))

static inline void fresh_message(const uint8_t seed[32], uint32_t index,
                                 uint8_t out[FRESH_MSG_BYTES]) {
    uint8_t in[39];
    memcpy(in, seed, 32);
    in[32] = (uint8_t)index;         in[33] = (uint8_t)(index >> 8);
    in[34] = (uint8_t)(index >> 16); in[35] = (uint8_t)(index >> 24);
    in[36] = 'R'; in[37] = 'P'; in[38] = 'T';
    shake256(out, FRESH_MSG_BYTES, in, sizeof in);
}

#endif /* FRESH_FIXTURE_H */
