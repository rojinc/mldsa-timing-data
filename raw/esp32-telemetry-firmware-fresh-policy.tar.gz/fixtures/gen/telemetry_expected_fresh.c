/*
 * telemetry_expected_fresh.c -- expected report digests for the fresh-input
 * telemetry policy (TEL_FRESH=1).
 *
 * Request i of a run with signing key k uses index FRESH_INDEX(k, i):
 *   randomness = SHAKE256(master_seed || uint32_le(index))[0:32]
 *   message    = SHAKE256(master_seed || uint32_le(index) || "RPT")[0:128]
 * exactly as the device derives them (components/pqcrypto_fx/fresh_fixture.h,
 * which this file includes, so the two cannot drift apart).
 *
 * Usage: telemetry_expected_fresh FIXTURE_DIR KEY N OUT_CSV
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "randombytes.h"
#include "fips202.h"
#include "api.h"
#include "fresh_fixture.h"

#define SK  PQCLEAN_MLDSA44_CLEAN_CRYPTO_SECRETKEYBYTES
#define PK  PQCLEAN_MLDSA44_CLEAN_CRYPTO_PUBLICKEYBYTES
#define SIG PQCLEAN_MLDSA44_CLEAN_CRYPTO_BYTES
#define RND 32

static uint8_t seed[32], armed[RND];
static int armed_ok; static size_t taken;

int randombytes(uint8_t *out, size_t n) {
    if (!armed_ok || n != RND || taken) {
        fprintf(stderr, "FATAL: unexpected randombytes(%zu)\n", n); exit(2);
    }
    memcpy(out, armed, RND); taken = RND; return 0;
}

static uint8_t *slurp(const char *d, const char *f, size_t n) {
    char p[512]; snprintf(p, sizeof p, "%s/%s", d, f);
    FILE *h = fopen(p, "rb"); uint8_t *b = malloc(n);
    if (!h || !b || fread(b, 1, n, h) != n) {
        fprintf(stderr, "FATAL: cannot read %s\n", p); exit(2);
    }
    fclose(h); return b;
}

int main(int argc, char **argv) {
    if (argc != 5) {
        fprintf(stderr, "usage: %s FIXTURE_DIR KEY N OUT_CSV\n", argv[0]);
        return 1;
    }
    const char *dir = argv[1];
    int key = atoi(argv[2]), n = atoi(argv[3]);
    uint8_t *sk = slurp(dir, "secret_keys.bin", (size_t)10 * SK);
    uint8_t *pk = slurp(dir, "public_keys.bin", (size_t)10 * PK);
    memcpy(seed, slurp(dir, "master_seed.bin", 32), 32);

    FILE *out = fopen(argv[4], "w");
    fprintf(out, "fixture_id,siglen,digest\n");
    uint8_t sigbuf[SIG], dg[8], msg[FRESH_MSG_BYTES];
    int bad = 0;
    for (int i = 0; i < n; i++) {
        uint32_t idx = FRESH_INDEX(key, i);
        uint8_t in[36]; memcpy(in, seed, 32);
        in[32]=(uint8_t)idx; in[33]=(uint8_t)(idx>>8); in[34]=(uint8_t)(idx>>16); in[35]=(uint8_t)(idx>>24);
        shake256(armed, RND, in, sizeof in);          /* same as fixture_rng_derive */
        fresh_message(seed, idx, msg);
        armed_ok = 1; taken = 0;
        size_t len = 0;
        if (PQCLEAN_MLDSA44_CLEAN_crypto_sign_signature(sigbuf, &len, msg, FRESH_MSG_BYTES, sk + (size_t)key * SK) != 0) bad++;
        if (PQCLEAN_MLDSA44_CLEAN_crypto_sign_verify(sigbuf, len, msg, FRESH_MSG_BYTES, pk + (size_t)key * PK) != 0) bad++;
        shake256(dg, sizeof dg, sigbuf, len);
        fprintf(out, "%d,%zu,", i, len);
        for (int b = 0; b < 8; b++) fprintf(out, "%02x", dg[b]);
        fprintf(out, "\n");
    }
    fclose(out);
    printf("key %d: %d fresh expected digests, %d reference failures\n", key, n, bad);
    return bad ? 1 : 0;
}
