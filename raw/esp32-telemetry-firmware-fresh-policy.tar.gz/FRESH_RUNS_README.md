# Fresh-input ESP32 telemetry runs — what to do

Everything needed for the fresh-message / fresh-randomness telemetry runs is in this folder.
Nothing here needs the internet except step 1 (pip). Each step is one command.

## 0. One command for everything

    cd ~/Desktop/research/mldsa-rp2040-results-20260911 && caffeinate -is tools/go_fresh.sh

Does steps 1-3 below in order and starts the matrix only if the smoke test is clean.

## 1. One-time setup (needs internet for pip only)

    cd ~/Desktop/research/mldsa-rp2040-results-20260911
    python3 -m venv .venv
    .venv/bin/pip install numpy==2.3.5 pandas==2.2.3 matplotlib==3.11.1 pyserial==3.5

The `vendor` symlink (-> ../pqc-wsn-bench-release/vendor) is already in place; the build
needs it for vendor/pqclean. ESP-IDF 5.2.1 is expected at ~/esp/esp-idf (the scripts source
~/esp/esp-idf/export.sh themselves). If the board is on a different serial port, prefix the
commands with `PORT=/dev/cu.XXXX` (default /dev/cu.SLAB_USBtoUART).

## 2. Smoke test (about 3 minutes, do this first)

    tools/smoke_fresh.sh

Builds one 20 s inline 100 ms run with key 1 under the fresh policy, flashes it, captures the
serial output into runs/telf_smoke and checks every report's 8-byte digest against the host
reference fixtures/telemetry_expected/key1_fresh.csv.

Good result looks like:

    capture: complete
    # fixture policy: fresh (message and randomness derived per request, fixture_id = request id)
    runs/telf_smoke  fresh  reports=200  mismatch=0  rc!=0=0  badlen=0

If mismatch is not 0, stop and send me runs/telf_smoke/telemetry_reports.csv and
runs/telf_smoke/device_meta.txt — do not start the matrix.

## 3. The matrix (about 3 h 15 min, leave the laptop open and plugged in)

    caffeinate -is tools/telemetry_fresh.sh 2>&1 | tee runs/telemetry_fresh.log

18 runs: inline and worker at 100, 250 and 1,000 ms, 600 s each, three replicates
(replicate r uses key r), in the same randomised condition orders as the fixed-fixture
matrix. Each run is built, flashed, captured into runs/telf_r{r}_{arch}_{period}ms, then
all runs are digest-checked and assembled. A run that is already captured is skipped, so
the same command can be re-run after an interruption; nothing is overwritten.

Short version if time is short: `caffeinate -is tools/telemetry_fresh.sh 1` runs replicate 1
only (6 runs, about 65 minutes).

## 4. What to send back

    runs/esp32_reports_fresh.csv     (all reports, same columns as esp32_reports.csv + replicate, mode, period_ms)
    runs/esp32_runs_fresh.csv        (one row per run: counters, distinct fixtures, capture status)
    runs/telemetry_fresh.log         (the console log)

or simply the whole runs/telf_* set of folders. The paper side (Sections IV-D, IX-C, IX-D,
Fig. 10, Table S2, the round-7 letter) is updated from these with pkg/analysis/fresh_esp32.py.

## What was changed in this folder (fixed-fixture builds are unaffected)

New files
- esp32-campaign/components/pqcrypto_fx/fresh_fixture.h — per-request message and randomness
  index: FRESH_INDEX(key, id) = 3,000,000 + 10,000*key + id (clear of every index used before),
  message = SHAKE256(master_seed || le32(index) || "RPT")[0:128].
- fixtures/gen/telemetry_expected_fresh.c — host reference generator for the fresh policy
  (same derivation, signs and verifies, 8-byte digest); the existing generator was first
  re-run and reproduced the archived key1.csv digests exactly.
- fixtures/telemetry_expected/key{1,2,3}_fresh.csv — 6,000 reference digests per key.
- tools/build_telemetry_fresh.sh, tools/smoke_fresh.sh, tools/telemetry_fresh.sh,
  tools/assemble_fresh.py.
- vendor -> ../pqc-wsn-bench-release/vendor (symlink).

Patched (originals kept as *.before-fresh)
- esp32-campaign/main/telemetry_main.c — under TEL_FRESH=1: derives the message before
  `start` is taken (charged to dispatch, as Table III states), arms the RNG with the fresh
  index, uses fixture_id = request id, prints "# fixture policy: fresh ..." in the banner.
  With TEL_FRESH=0 (the default) the code path is byte-for-byte the previous one.
- esp32-campaign/main/telemetry_config.h, esp32-campaign/CMakeLists.txt,
  esp32-campaign/main/CMakeLists.txt — TEL_FRESH option (default 0).
- tools/check_report_signatures.py — detects fresh runs from device_meta.txt and checks them
  against key{k}_fresh.csv.

Engine, queue, admission timer, tasks and CSV columns are unchanged.
