#!/bin/sh
# One command for the whole fresh-input experiment:
#   caffeinate -is tools/go_fresh.sh
# 1. creates .venv if missing (the only step that needs the internet),
# 2. runs the 3-minute smoke test,
# 3. starts the 18-run matrix only if the smoke test is clean
#    (capture complete, fresh policy in the banner, >=150 reports checked, 0 failures).
set -u
HERE=$(cd "$(dirname "$0")/.." && pwd); cd "$HERE"
mkdir -p runs
if [ ! -x .venv/bin/python ]; then
    echo "=== creating .venv (needs internet once)"
    python3 -m venv .venv && .venv/bin/pip install -q numpy==2.3.5 pandas==2.2.3 matplotlib==3.11.1 pyserial==3.5 \
        || { echo "venv setup failed - connect to the internet and run again"; exit 1; }
fi
echo "=== smoke test  $(date)"
tools/smoke_fresh.sh 2>&1 | tee runs/telf_smoke.log
summary=$(.venv/bin/python tools/check_report_signatures.py runs/telf_smoke 2>/dev/null | tail -1)
checked=$(echo "$summary" | awk '{print $1}')
fails=$(echo "$summary" | awk '{print $(NF-1)}')
if grep -q "fixture policy: fresh" runs/telf_smoke/device_meta.txt 2>/dev/null \
   && [ "${checked:-0}" -ge 150 ] && [ "${fails:-1}" -eq 0 ]; then
    echo "=== smoke test clean ($summary): starting the matrix  $(date)"
    tools/telemetry_fresh.sh 2>&1 | tee runs/telemetry_fresh.log
    echo "=== finished  $(date)"
else
    echo "=== SMOKE TEST NOT CLEAN ($summary) - matrix NOT started. See runs/telf_smoke.log and build/telf-inline-100ms-20s-k1.log"
    exit 1
fi
