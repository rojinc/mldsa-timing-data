#!/usr/bin/env python3
"""Concatenate the fresh-input telemetry runs into runs/esp32_reports_fresh.csv
(same schema as the released esp32_reports.csv: replicate, mode, period_ms,
then the device columns) and runs/esp32_runs_fresh.csv (one row per run with
the banner counters). Run from the repository root or anywhere."""
import re, sys
from pathlib import Path
import pandas as pd

HERE = Path(__file__).resolve().parents[1]
rows, runs = [], []
for d in sorted((HERE / "runs").glob("telf_r*_*ms")):
    m = re.match(r"telf_r(\d+)_(inline|worker)_(\d+)ms$", d.name)
    rep = d / "telemetry_reports.csv"
    if not m or not rep.is_file():
        continue
    r, mode, period = int(m.group(1)), m.group(2), int(m.group(3))
    df = pd.read_csv(rep)
    df.insert(0, "period_ms", period); df.insert(0, "mode", mode); df.insert(0, "replicate", r)
    rows.append(df)
    meta = (d / "device_meta.txt").read_text() if (d / "device_meta.txt").is_file() else ""
    kv = {}
    for line in meta.splitlines():
        for part in line.lstrip("# ").split():
            if "=" in part:
                k, v = part.split("=", 1)
                try: kv[k] = int(v)
                except ValueError: pass
    status = (d / "capture_status.txt").read_text().strip() if (d / "capture_status.txt").is_file() else ""
    runs.append(dict(replicate=r, mode=mode, period_ms=period, run_dir=d.name, rows=len(df),
                     distinct_fixtures=int(df.fixture_id.nunique()), fresh=("fixture policy: fresh" in meta),
                     capture=status.replace("status=", ""), **kv))
if not rows:
    sys.exit("no telf_r*_*ms runs with telemetry_reports.csv found under runs/")
out = pd.concat(rows, ignore_index=True)
out.to_csv(HERE / "runs/esp32_reports_fresh.csv", index=False)
R = pd.DataFrame(runs); R.to_csv(HERE / "runs/esp32_runs_fresh.csv", index=False)
pd.set_option("display.width", 200)
print(R.to_string())
print(f"\nwrote runs/esp32_reports_fresh.csv ({len(out)} rows) and runs/esp32_runs_fresh.csv ({len(R)} runs)")
bad = R[~R.fresh | (R.distinct_fixtures < R.rows)]
if len(bad):
    print("WARNING: these runs are not fresh-input runs (banner or repeated fixture ids):"); print(bad[["run_dir", "fresh", "distinct_fixtures", "rows"]].to_string())
