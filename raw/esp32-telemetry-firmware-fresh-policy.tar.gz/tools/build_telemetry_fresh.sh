#!/bin/sh
# Build one fresh-input telemetry condition (TEL_FRESH=1).
#   tools/build_telemetry_fresh.sh ARCH PERIOD_MS SECONDS KEY
# ARCH: inline | worker.  Output: build/telf-ARCH-PERIODms-SECONDSs-kKEY
set -eu
HERE=$(cd "$(dirname "$0")/.." && pwd)
ARCH=${1:?inline|worker}; PERIOD=${2:-100}; SECS=${3:-600}; KEY=${4:-1}
[ "$ARCH" = "worker" ] && W=1 || W=0
NAME="telf-$ARCH-${PERIOD}ms-${SECS}s-k${KEY}"
BUILD="$HERE/build/$NAME"
mkdir -p "$HERE/build"
# Seeded from the archival sdkconfig so optimisation, clock and core settings
# match the fixed-fixture runs.
[ -f "$HERE/build/campaign.sdkconfig" ] || cp "$HERE/esp32-project/sdkconfig" "$HERE/build/campaign.sdkconfig"
[ -e "$HERE/vendor/pqclean" ] || { echo "vendor/pqclean missing: ln -s ../pqc-wsn-bench-release/vendor vendor"; exit 1; }
. "$HOME/esp/esp-idf/export.sh" >/dev/null 2>&1
idf.py -C "$HERE/esp32-campaign" -B "$BUILD" \
    -D SDKCONFIG="$HERE/build/campaign.sdkconfig" -D CAMPAIGN_APP=telemetry \
    -D TEL_WORKER=$W -D TEL_REPORT_PERIOD_US=$((PERIOD * 1000)) \
    -D TEL_RUN_SECONDS=$SECS -D TEL_KEY=$KEY -D TEL_NO_SIGNING=0 -D TEL_FRESH=1 build > "$BUILD.log" 2>&1 \
    || { tail -25 "$BUILD.log"; exit 1; }
printf '%-28s ' "$NAME"; shasum -a 256 "$BUILD/mldsa_campaign_esp32.bin" | cut -c1-16
