#!/usr/bin/env python3
"""Capture a device's serial output to a raw log, then parse and validate it.

Guarantees:
  * never overwrites an existing capture -- refuses, or allocates the next
    attempt directory with --new-attempt
  * detects the completion marker even when it is split across serial reads
  * uses a monotonic clock for elapsed time and timeouts, so a wall-clock
    adjustment cannot shorten a run or fake a timeout
  * a run is "complete" only after the marker AND the record validation pass;
    anything else stays labelled incomplete and out of the summaries

Usage: capture_serial.py PORT OUT_DIR [options]
"""
import argparse
import json
import sys
import time
from pathlib import Path

import serial

BASELINE_HEADER = "algorithm,operation,security_level,time_us,run_number"
CAMPAIGN_HEADER = ("invocation_id,block,key_id,message_id,rand_index,"
                   "start_us,end_us,elapsed_us,K,reject_z,reject_w0,reject_ct0,"
                   "reject_hint,sign_rc,verify_rc,siglen,rng_ok,k_ok")
# Telemetry emits three sections in one run.
TEL_HIST_HEADER = "hist_bucket_us,start_jitter,completion_response"
TEL_ACQ_HEADER  = "acq_index,start_off_us,duration_us,skipped"
# v1 had no per-report signature validation; v2 adds fixture id, return
# code, length and the SHAKE256 digest checked against host-computed
# expected signatures. Both are parsed so earlier runs still load.
TEL_REP_HEADER_V1 = "rep_id,released_us,started_off_us,ready_off_us,queue_depth,status"
TEL_REP_HEADER  = (TEL_REP_HEADER_V1 +
                   ",fixture_id,sign_rc,siglen,digest")
TEL_HEADERS = {TEL_HIST_HEADER: "telemetry_hist.csv",
               TEL_ACQ_HEADER: "telemetry_acq_exceptions.csv",
               TEL_REP_HEADER: "telemetry_reports.csv",
               TEL_REP_HEADER_V1: "telemetry_reports.csv"}
KNOWN_HEADERS = (BASELINE_HEADER, CAMPAIGN_HEADER) + tuple(TEL_HEADERS)
DEFAULT_MARKER = "benchmarks complete"
# Expected rows per operation for the baseline ML-DSA firmware. Override with
# --expect when a build uses different sample sizes.
DEFAULT_EXPECT = {"keygen": 1000, "verify": 1000, "sign": 10000}


class MarkerScanner:
    """Finds `marker` in a byte stream arriving in arbitrary chunks.

    Keeps the last len(marker)-1 bytes so a marker straddling two reads is
    still detected. A plain `marker in chunk` test misses exactly that case
    and silently turns a finished run into an idle timeout.
    """

    def __init__(self, marker):
        self.marker = marker.encode()
        self.tail = b""

    def feed(self, chunk):
        if not self.marker:
            return False
        window = self.tail + chunk
        found = self.marker in window
        keep = len(self.marker) - 1
        self.tail = window[-keep:] if keep else b""
        return found


def open_output(out_dir, new_attempt):
    """Return a directory that does not already hold a capture."""
    raw = out_dir / "raw_serial.bin"
    if not raw.exists():
        out_dir.mkdir(parents=True, exist_ok=True)
        return out_dir
    if not new_attempt:
        sys.exit(f"REFUSING: {raw} exists. Existing captures are never "
                 f"overwritten. Pass --new-attempt for the next attempt "
                 f"directory, or choose another OUT_DIR.")
    for n in range(2, 1000):
        cand = out_dir.parent / f"{out_dir.name}_attempt{n:02d}"
        if not (cand / "raw_serial.bin").exists():
            cand.mkdir(parents=True, exist_ok=True)
            print(f"existing capture found; using {cand}")
            return cand
    sys.exit("REFUSING: too many attempt directories")


def reset_device(ser):
    """Pulse EN via RTS so the firmware restarts with the port already open.

    Without this the run begins during flashing and the identity banner is
    lost. DTR low keeps GPIO0 high so the chip boots the application.
    """
    ser.dtr = False
    ser.rts = True
    time.sleep(0.1)
    ser.rts = False
    ser.reset_input_buffer()


def capture(port, out_dir, baud, idle_timeout, marker, do_reset):
    raw = out_dir / "raw_serial.bin"
    scanner = MarkerScanner(marker)
    # Monotonic: immune to NTP steps and DST, unlike time.time().
    with serial.Serial(port, baud, timeout=1) as ser, open(raw, "xb") as fh:
        if do_reset:
            reset_device(ser)
        started = last = time.monotonic()
        print(f"capturing {port} -> {raw}", flush=True)
        while True:
            chunk = ser.read(4096)
            now = time.monotonic()
            if chunk:
                fh.write(chunk)
                fh.flush()
                last = now
                if scanner.feed(chunk):
                    return "marker_seen", now - started
            elif now - last > idle_timeout:
                print(f"IDLE {idle_timeout}s -- incomplete", flush=True)
                return "incomplete_idle_timeout", now - started


def parse(out_dir):
    """Split the raw log into metadata and the rows of whichever known schema
    the firmware emitted. An unrecognised header yields no rows, so validation
    fails loudly rather than silently accepting a schema change."""
    text = (out_dir / "raw_serial.bin").read_bytes().decode("utf-8", "replace")
    rows, meta, header, sections = [], [], None, {}
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        if line.startswith("STAGE,"):
            # Stage events are interleaved with campaign records and carry
            # their own prefix rather than a header line.
            sections.setdefault("STAGE", []).append(line[len("STAGE,"):])
            continue
        if (line.startswith("#") or line.startswith("run_schema,")
                or line.startswith("stage_schema,")):
            meta.append(line)
        elif line in KNOWN_HEADERS:
            header = line
            sections.setdefault(header, [])
        elif header and line.count(",") == header.count(","):
            rows.append(line)
            sections[header].append(line)
    (out_dir / "device_meta.txt").write_text("\n".join(meta) + "\n")
    if "STAGE" in sections:
        (out_dir / "stage_events.csv").write_text(
            "invocation,candidate,label,t_us,overflow\n"
            + "\n".join(sections.pop("STAGE")) + "\n")
    if any(h in TEL_HEADERS for h in sections):
        for h, rs in sections.items():
            (out_dir / TEL_HEADERS[h]).write_text(h + "\n" + "\n".join(rs) + "\n")
        return rows, meta, "telemetry"
    name = "campaign.csv" if header == CAMPAIGN_HEADER else "mldsa.csv"
    (out_dir / name).write_text((header or "UNKNOWN_SCHEMA") + "\n"
                                + "\n".join(rows) + "\n")
    return rows, meta, header


def validate_telemetry(out_dir, meta):
    """Telemetry runs are validated from the device's own accounting.

    Every generated request must be accounted for, no log may have
    overflowed, and the acquisition totals must balance. A run failing any of
    these is not usable for timing conclusions and stays labelled incomplete.
    """
    c = {"schema": "telemetry"}
    kv = {}
    for line in meta:
        for part in line.lstrip("# ").split():
            if "=" in part:
                k, v = part.split("=", 1)
                try:
                    kv[k] = int(v)
                except ValueError:
                    pass
    c.update(kv)

    reps = len((out_dir / "telemetry_reports.csv").read_text().strip().splitlines()) - 1 \
        if (out_dir / "telemetry_reports.csv").is_file() else 0
    c["report_rows"] = reps

    admitted, dropped = kv.get("admitted", -1), kv.get("dropped", -1)
    completed, censored = kv.get("completed", -1), kv.get("censored", -1)
    total = kv.get("total", -1)
    on_time, late, skipped = (kv.get("on_time", -1), kv.get("late", -1),
                              kv.get("skipped", -1))

    c["queue_balances"] = (admitted >= 0 and
                           admitted == completed + censored)
    c["acq_balances"] = (total >= 0 and total == on_time + late + skipped)
    # Two different kinds of log. The report ring carries every timing record
    # the analysis depends on, so its overflow invalidates the run. The
    # acquisition exception ring is a bounded diagnostic sample of late and
    # skipped releases; the acquisition counters themselves are exact and
    # unbounded, so a truncated sample is recorded, not fatal.
    c["report_log_overflow"] = kv.get("reports", 0)
    c["acq_exception_log_truncated"] = kv.get("acq_exceptions", 0)
    c["no_overflow"] = c["report_log_overflow"] == 0
    # An acquisition-only baseline releases no reports by design, so an empty
    # report log is correct there and only an error when signing was enabled.
    c["signing_enabled"] = not any("signing enabled: no" in l for l in meta)
    c["reports_expected"] = c["signing_enabled"]
    c["all_passed"] = bool(c["queue_balances"] and c["acq_balances"]
                           and c["no_overflow"]
                           and (reps > 0 or not c["signing_enabled"]))
    return c


def validate_campaign(rows, expect_n):
    """Campaign schema: sequence, timings, return codes and the K identity."""
    c = {"schema": "campaign", "rows": len(rows), "expected": expect_n,
         "schema_violations": 0, "sign_failures": 0, "verify_failures": 0,
         "rng_not_ok": 0, "k_identity_failures": 0, "nonpositive_elapsed": 0}
    ids = []
    for line in rows:
        f = line.split(",")
        if len(f) != 18:
            c["schema_violations"] += 1
            continue
        try:
            inv = int(f[0]); elapsed = int(f[7])
            K, z, w0, ct0, hint = (int(f[8]), int(f[9]), int(f[10]),
                                   int(f[11]), int(f[12]))
            rc, vrc, rng_ok, k_ok = int(f[13]), int(f[14]), int(f[16]), int(f[17])
        except ValueError:
            c["schema_violations"] += 1
            continue
        ids.append(inv)
        if elapsed <= 0:
            c["nonpositive_elapsed"] += 1
        if rc != 0:
            c["sign_failures"] += 1
        if vrc != 0:
            c["verify_failures"] += 1
        if rng_ok != 1:
            c["rng_not_ok"] += 1
        # k_ok is -1 in the plain build, which keeps no counters.
        if k_ok == 0 or (k_ok == 1 and K != 1 + z + w0 + ct0 + hint):
            c["k_identity_failures"] += 1
    c["duplicates"] = len(ids) - len(set(ids))
    c["sequence_complete"] = bool(
        len(ids) == expect_n and len(set(ids)) == expect_n
        and max(ids, default=-1) - min(ids, default=0) == expect_n - 1)
    c["all_passed"] = bool(
        c["sequence_complete"] and c["duplicates"] == 0
        and all(c[k] == 0 for k in ("schema_violations", "sign_failures",
                                    "verify_failures", "rng_not_ok",
                                    "k_identity_failures", "nonpositive_elapsed")))
    return c


def validate(rows, expect):
    """Schema, counts and per-operation sequence completeness."""
    checks, by_op = {}, {}
    bad_schema = 0
    for line in rows:
        parts = line.split(",")
        if len(parts) != 5:
            bad_schema += 1
            continue
        try:
            op, t, n = parts[1], int(parts[3]), int(parts[4])
        except ValueError:
            bad_schema += 1
            continue
        if t <= 0:
            bad_schema += 1
            continue
        by_op.setdefault(op, []).append(n)

    checks["schema"] = "baseline"
    checks["schema_violations"] = bad_schema
    checks["operations"] = {}
    ok = bad_schema == 0
    for op, want in expect.items():
        got = by_op.get(op, [])
        complete = (len(got) == want and len(set(got)) == want
                    and min(got, default=0) == 1 and max(got, default=0) == want)
        checks["operations"][op] = {
            "rows": len(got), "expected": want,
            "duplicates": len(got) - len(set(got)),
            "sequence_complete": complete,
        }
        ok &= complete
    for op in set(by_op) - set(expect):
        checks["operations"][op] = {"rows": len(by_op[op]),
                                    "expected": "not specified"}
    checks["all_passed"] = bool(ok)
    return checks


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("port")
    ap.add_argument("out_dir", type=Path)
    ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--idle-timeout", type=float, default=900.0)
    ap.add_argument("--done-marker", default=DEFAULT_MARKER)
    ap.add_argument("--no-reset", action="store_true")
    ap.add_argument("--new-attempt", action="store_true",
                    help="allocate the next attempt directory instead of refusing")
    ap.add_argument("--expect", default=None,
                    help='JSON of expected row counts, e.g. \'{"sign": 10000}\'')
    ap.add_argument("--expect-n", type=int, default=10000,
                    help="expected campaign-schema invocation count")
    a = ap.parse_args()

    expect = json.loads(a.expect) if a.expect else DEFAULT_EXPECT
    out_dir = open_output(a.out_dir, a.new_attempt)

    marker_state, elapsed = capture(a.port, out_dir, a.baud, a.idle_timeout,
                                    a.done_marker, not a.no_reset)
    rows, _, header = parse(out_dir)
    if header == "telemetry":
        checks = validate_telemetry(out_dir, _)
    elif header == CAMPAIGN_HEADER:
        checks = validate_campaign(rows, int(a.expect_n))
    elif header == BASELINE_HEADER:
        checks = validate(rows, expect)
    else:
        checks = {"schema": "UNRECOGNISED", "rows": len(rows),
                  "all_passed": False, "operations": {}}

    # A run is complete only if the device said so AND the records validate.
    status = ("complete" if marker_state == "marker_seen" and checks["all_passed"]
              else marker_state if marker_state != "marker_seen"
              else "incomplete_failed_validation")

    (out_dir / "capture_status.txt").write_text(
        f"status={status}\nelapsed_s={elapsed:.1f}\nrows={len(rows)}\n"
        f"port={a.port}\nmarker={marker_state}\n")
    (out_dir / "validation.json").write_text(json.dumps(checks, indent=2) + "\n")

    print(f"status={status} elapsed={elapsed:.0f}s rows={len(rows)}")
    if status != "complete":
        for op, c in checks.get("operations", {}).items():
            if not c.get("sequence_complete", True):
                print(f"  {op}: {c['rows']} of {c['expected']} rows, "
                      f"{c.get('duplicates', 0)} duplicates")
        for k, v in checks.items():
            if isinstance(v, int) and v and k not in ("rows", "expected"):
                print(f"  {k}: {v}")
    return 0 if status == "complete" else 1


if __name__ == "__main__":
    sys.exit(main())
