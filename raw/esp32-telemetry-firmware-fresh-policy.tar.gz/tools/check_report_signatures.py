#!/usr/bin/env python3
"""Compare each device report digest against the host's expected digest.

The telemetry firmware emits an 8-byte SHAKE256 of every signature it
produces. This checks all of them against signatures the host computed and
verified independently, so the report outputs are validated without pushing
2.4 KB per report through the UART inside the measured window.

Usage: check_report_signatures.py RUN_DIR [RUN_DIR ...]
"""
import re
import sys
from pathlib import Path

import pandas as pd

EXPECTED_DIR = Path(__file__).resolve().parents[1] / "fixtures/telemetry_expected"


def key_of(run_dir):
    """Replicate number is the signing key; taken from the device banner."""
    meta = (run_dir / "device_meta.txt")
    if meta.is_file():
        m = re.search(r"# signing key: (\d+)", meta.read_text())
        if m:
            return int(m.group(1))
    return None


def is_fresh(run_dir):
    """Fresh-input runs announce their policy in the banner; their expected
    digests live in key<k>_fresh.csv (one per request id)."""
    meta = (run_dir / "device_meta.txt")
    return meta.is_file() and "# fixture policy: fresh" in meta.read_text()


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    total_checked = total_bad = 0
    print(f"{'run':<26}{'key':>4}{'checked':>9}{'mismatch':>10}"
          f"{'rc!=0':>7}{'badlen':>8}")
    print("-" * 64)
    for d in sys.argv[1:]:
        d = Path(d)
        rep = d / "telemetry_reports.csv"
        if not rep.is_file():
            continue
        df = pd.read_csv(rep)
        if "digest" not in df.columns:
            print(f"{d.name:<26}{'':>4}{'no digest column (older firmware)':>9}")
            continue
        k = key_of(d)
        exp = pd.read_csv(EXPECTED_DIR / (f"key{k}_fresh.csv" if is_fresh(d) else f"key{k}.csv"))
        exp = exp.assign(digest=exp.digest.astype(str))
        m = df[df.status == 0].merge(exp, on="fixture_id",
                                     suffixes=("_dev", "_exp"))
        bad = (m.digest_dev.astype(str).str.lower()
               != m.digest_exp.str.lower()).sum()
        rc = int((m.sign_rc != 0).sum())
        badlen = int((m.siglen_dev != m.siglen_exp).sum())
        total_checked += len(m)
        total_bad += int(bad) + rc + badlen
        print(f"{d.name:<26}{k:>4}{len(m):>9}{bad:>10}{rc:>7}{badlen:>8}"
              + ("  fresh" if is_fresh(d) else ""))

    print("-" * 64)
    print(f"{total_checked} report signatures checked, {total_bad} failures")
    return 1 if total_bad else 0


if __name__ == "__main__":
    sys.exit(main())
