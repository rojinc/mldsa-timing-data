#!/bin/sh
# Fresh-input telemetry matrix: 2 architectures x 3 periods x 3 replicates,
# 600 s each, about 3 h 15 min including builds and drains.
#
#   caffeinate -is tools/telemetry_fresh.sh 2>&1 | tee runs/telemetry_fresh.log
#
# Same structure as telemetry_matrix_v2.sh (one key per replicate, conditions
# in the stored randomised order, nothing overwritten); only the fixture
# policy differs: every request derives its own message and randomness.
# Pass a single replicate number as $1 to run one replicate only.
set -u
HERE=$(cd "$(dirname "$0")/.." && pwd)
cd "$HERE"
PORT=${PORT:-/dev/cu.SLAB_USBtoUART}; export PORT
ONLY=${1:-}
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
LEDGER="$HERE/runs/telemetry_fresh_${STAMP}_ledger.csv"
echo "phase,condition,status,seconds,out_dir" > "$LEDGER"
say() { printf '\n=== %s  %s\n' "$1" "$(date -u +%FT%TZ)"; }
record() { printf '%s,%s,%s,%s,%s\n' "$1" "$2" "$3" "$4" "$5" >> "$LEDGER"; }
run_one() {  # phase condition build_name out_dir expect marker idle
    phase=$1; cond=$2; build=$3; out=$4; expect=$5; marker=$6; idle=${7:-900}
    t0=$(date +%s)
    if MARKER="$marker" IDLE="$idle" ./tools/flash_and_run.sh "$build" "$out" "$expect" \
        > "runs/$(basename "$out").flashlog" 2>&1; then
        st=$(sed -n 's/^status=//p' "$out/capture_status.txt" 2>/dev/null); [ -n "$st" ] || st=unknown
    else
        st=$(sed -n 's/^status=//p' "$out/capture_status.txt" 2>/dev/null); [ -n "$st" ] || st=flash_or_capture_failed
    fi
    t1=$(date +%s); record "$phase" "$cond" "$st" "$((t1 - t0))" "$out"
    printf '    %-34s %-32s %ss\n' "$cond" "$st" "$((t1 - t0))"
}
say "FRESH-INPUT TELEMETRY MATRIX"
REP1="worker:250 inline:1000 worker:100 inline:250 worker:1000 inline:100"
REP2="inline:100 worker:1000 inline:250 worker:100 inline:1000 worker:250"
REP3="worker:1000 inline:250 worker:100 inline:100 worker:250 inline:1000"
r=1
for order in "$REP1" "$REP2" "$REP3"; do
    if [ -n "$ONLY" ] && [ "$ONLY" != "$r" ]; then r=$((r + 1)); continue; fi
    key=$r
    for cond in $order; do
        arch=${cond%%:*}; period=${cond##*:}
        name="telf-${arch}-${period}ms-600s-k${key}"
        out="runs/telf_r${r}_${arch}_${period}ms"
        if [ -e "$out/raw_serial.bin" ]; then printf '    %-34s already captured, skipped\n' "$out"; continue; fi
        ./tools/build_telemetry_fresh.sh "$arch" "$period" 600 "$key" > /dev/null 2>&1 || {
            record fresh "r${r}_${arch}_${period}ms" build_failed 0 -; continue; }
        case $period in 100) n=6000;; 250) n=2400;; *) n=600;; esac
        run_one fresh "r${r}_${arch}_${period}ms" "$name" "$out" "$n" "telemetry run complete" 900
    done
    r=$((r + 1))
done
say "DIGEST CHECK"
.venv/bin/python tools/check_report_signatures.py runs/telf_r*_*ms
say "ASSEMBLE"
.venv/bin/python tools/assemble_fresh.py
say "ALL DONE"
column -s, -t "$LEDGER" 2>/dev/null || cat "$LEDGER"
echo "ledger: $LEDGER"
