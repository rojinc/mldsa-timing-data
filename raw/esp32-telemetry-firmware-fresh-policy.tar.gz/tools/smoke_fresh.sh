#!/bin/sh
# Smoke test for the fresh-input policy: one 20 s inline run at 100 ms with
# key 1, then the host digest check. Takes about 3 minutes including the
# build. Run this before the 3-hour matrix.
set -u
HERE=$(cd "$(dirname "$0")/.." && pwd)
cd "$HERE"
PORT=${PORT:-/dev/cu.SLAB_USBtoUART}; export PORT
rm -rf runs/telf_smoke runs/telf_smoke.flashlog
./tools/build_telemetry_fresh.sh inline 100 20 1 || exit 1
MARKER="telemetry run complete" IDLE=120 ./tools/flash_and_run.sh telf-inline-100ms-20s-k1 runs/telf_smoke 200 \
    > runs/telf_smoke.flashlog 2>&1
echo "capture: $(sed -n 's/^status=//p' runs/telf_smoke/capture_status.txt 2>/dev/null)"
grep -h "fixture policy\|queue:\|releases:" runs/telf_smoke/device_meta.txt 2>/dev/null
.venv/bin/python tools/check_report_signatures.py runs/telf_smoke
echo "If the line above shows 0 mismatch, 0 rc!=0 and 0 badlen, the device and the host derive"
echo "identical fresh inputs and the matrix can run: tools/telemetry_fresh.sh"
