#!/bin/sh
# Flash one campaign build and capture its run.
#   tools/flash_and_run.sh BUILD_NAME OUT_RUN_DIR [EXPECTED_ROWS]
set -eu
HERE=$(cd "$(dirname "$0")/.." && pwd)
NAME=${1:?build name}
OUT=${2:?out dir}
EXPECT=${3:-1000}
MARKER=${MARKER:-"campaign block"}
# The telemetry firmware logs to a RAM ring and prints nothing until its
# measured window closes, so the idle timeout must exceed the whole run plus
# the drain. Campaign runs stream continuously and need only a short one.
IDLE=${IDLE:-300}
PORT=${PORT:-/dev/cu.SLAB_USBtoUART}
B="$HERE/build/$NAME"

. "$HOME/esp/esp-idf/export.sh" >/dev/null 2>&1
python -m esptool --chip esp32 --port "$PORT" -b 460800 \
    --before default_reset --after hard_reset write_flash \
    --flash_mode dio --flash_size 2MB --flash_freq 40m \
    0x1000 "$B/bootloader/bootloader.bin" \
    0x8000 "$B/partition_table/partition-table.bin" \
    0x10000 "$B/mldsa_campaign_esp32.bin" 2>&1 | tail -3

"$HERE/.venv/bin/python" "$HERE/tools/capture_serial.py" "$PORT" "$HERE/$OUT" \
    --idle-timeout "$IDLE" --done-marker "$MARKER" \
    --expect-n "$EXPECT" || true
"$HERE/.venv/bin/python" "$HERE/tools/record_manifest.py" "$HERE/$OUT" \
    "$B/mldsa_campaign_esp32.bin" > /dev/null
