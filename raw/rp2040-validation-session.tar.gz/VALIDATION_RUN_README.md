# RP2040 validation blocks for the frozen calibration-coverage rule

Purpose: test the calibration rule of Section VIII-D on data nobody has seen. The rule and the
deadlines it predicts for every configuration are fixed in `frozen_rule.json`; its SHA-256 is in
`frozen_rule.sha256` and is written into the session record when the run starts. Nothing in the
rule may change after the new blocks exist.

What runs: both Pico boards in parallel, ML-DSA-65 first (the configuration that failed), then 44
and 87; for each set two new reset-separated boot blocks of 5,000 signatures (10 keys x 5 messages x
100 repetitions, counting mode, fresh OS-generated randomness recorded per block, 100 warm-up
calls after each reset). 30,000 main signatures per board, 60,000 in all. About 3.5 hours.

## 1. Flash the two boards (2 minutes, once)

The boards currently hold the telemetry firmware. For each board: hold BOOTSEL, plug the USB cable
in, release BOOTSEL; a drive named RPI-RP2 appears; copy `firmware/rp2040_campaign.uf2` onto it
(drag and drop); the drive disappears when the board reboots. This is the same campaign firmware as
in September (build 7a8c23b6..., UF2 sha256 cacc9f3e...); the host refuses any other build.
Leave both boards plugged in with data cables; close any serial monitor.

## 2. One command (needs internet only for the first-time pyserial install)

    cd ~/Desktop/research/mldsa-rp2040-results-20260911/rp2040-validation && ./run_validation.sh

It creates `.venv`, checks the frozen-rule hash, runs a 3-minute smoke check (both boards, 50
signatures per set with real resets and full validation), and starts the validation blocks only
if the smoke check completed. Progress lines show the remaining minutes of the current block.
Good signs: `rp2040_1 = E66368254F75782F: found on /dev/cu.usbmodem...` for both boards,
`SMOKE CHECK COMPLETE`, then `rp2040_1: set65_vblock5 COMPLETE (5,100 recorded invocations)` and
so on, ending with `VALIDATION COMPLETE: 30,000 main signatures per board.`

If a board is not found: check the cable (data, not charge-only), re-flash, run the command again.
If the run is interrupted: run the same command again; completed blocks are kept and the session
resumes after a fresh reset.

## 3. What to send back

The session folder `results/validation_<stamp>_<id>/` (about 40 MB) and `results/validation.log`,
or just say it is done and I will read it from this folder. The per-board attempt folders hold the
raw USB bytes, commands, parsed rows, randomness and status records exactly as in the original
campaign.

## Files

host/campaign.py, protocol.py, analyze.py   unchanged from the restored September package
host/validate_blocks.py                      validation runner (imports campaign.py; new phase names set<N>_vblock5, _vblock6)
fixtures/, firmware/, build-manifest.json, CHECKSUMS.json   restored package; checksums verified on every start
original_session.json                        board-label to hardware-ID mapping of the original campaign
frozen_rule.json, frozen_rule.sha256         the pre-registered rule and predicted deadlines (computed from the original campaign only)
