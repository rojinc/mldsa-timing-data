"""Validation campaign for the frozen calibration-coverage rule (manuscript Section VIII-D).

Runs new reset-separated boot blocks on the two RP2040 boards of the original campaign, with
fresh OS-generated signing randomness, the same ten keys and five messages, counting mode, and
the same protocol, validation and integrity records as the original campaign (campaign.py is
imported unchanged).  Nothing from the original session is touched.

    python3 host/validate_blocks.py                 # both boards, sets 65, 44, 87; 2 blocks x 5,000 calls per set
    python3 host/validate_blocks.py --smoke         # 1 block of 50 calls per set, both boards (about 3 minutes)
    python3 host/validate_blocks.py --boards rp2040_1 --sets 65     # one board, one set
    python3 host/validate_blocks.py --resume results/validation_...  # continue an interrupted session

Board labels are fixed by hardware ID from the original session (original_session.json), so
rp2040_1 and rp2040_2 mean the same physical boards as in the paper.  The session records the
SHA-256 of frozen_rule.json (the pre-registered rule and predicted deadlines) at creation.
"""
from pathlib import Path
import argparse, concurrent.futures, datetime, hashlib, json, os, platform, secrets, sys, time, traceback, uuid
sys.path.insert(0, str(Path(__file__).resolve().parent))
import campaign as C
from campaign import Worker, say, utc, save_json, digest, discover, schedule, STOP

ROOT = C.ROOT
SET_ORDER = (65, 44, 87)          # the configuration that failed in the paper goes first
BLOCKS = 2
REPETITIONS = 100                 # 10 keys x 5 messages x 100 = 5,000 main calls per block
FIRST_BLOCK = 5                   # original blocks were 0-4; validation blocks are numbered 5, 6, ...

def package_check_local():
    """Verify the files this run uses against the original package checksums (the Windows runtime
    and launchers are not part of this copy)."""
    expected = json.loads((ROOT / 'CHECKSUMS.json').read_text())
    checked = {}
    for name, sha in expected.items():
        p = ROOT / name
        if name.startswith(('host/', 'fixtures/', 'firmware/')) or name == 'build-manifest.json':
            if not p.exists(): raise RuntimeError(f'Missing package file: {name}')
            if digest(p) != sha: raise RuntimeError(f'Package checksum mismatch: {name}')
            checked[name] = sha
    return checked

class ValidationWorker(Worker):
    def __init__(self, session, label, uid, build, smoke, sets, blocks, reps):
        super().__init__(session, label, uid, build, smoke)
        self.sets = sets; self.blocks = blocks; self.reps = reps
    def expected_rows(self, name):
        if '_vblock' in name: return 100 + 10 * 5 * self.reps
        return super().expected_rows(name)
    def validation_block(self, level, vb):
        block = FIRST_BLOCK + vb
        count = 10 * 5 * self.reps
        rng = self.randoms(level, f'vblock{block}', 100 + count)
        seedfile = self.session / f'{self.label}_{level}_vblock{block}_schedule.json'
        if not seedfile.exists(): save_json(seedfile, {'seed': secrets.randbits(64), 'repetitions': self.reps})
        config = json.loads(seedfile.read_text()); rows = schedule(config['seed'], config['repetitions'])
        if len(rows) != count: raise RuntimeError('Schedule count mismatch')
        import csv
        with (self.attempt.path / 'schedule.csv').open('x', newline='') as f:
            w = csv.writer(f); w.writerow(['index', 'key', 'message', 'repetition', 'partition'])
            for i, (key, msg, rep) in enumerate(rows): w.writerow([i, key, msg, rep, 'validation'])
        self.warmup(level, rng[:100]); start = time.monotonic()
        for i, (key, msg, rep) in enumerate(rows):
            self.sign(level, key, msg, 1, rng[100 + i], i, 'main', boot_block=block, repetition=rep, partition='validation')
            if (i + 1) % 100 == 0:
                remain = (time.monotonic() - start) / (i + 1) * (count - i - 1) / 60
                say(f'{self.label}: set {level}, validation block {vb + 1}/{self.blocks} (boot block {block}), {i + 1:,}/{count:,}; about {remain:.0f} min remaining in this block')
    def run(self):
        for level in self.sets:
            for vb in range(self.blocks):
                self.do_phase(f'set{level}_vblock{FIRST_BLOCK + vb}', lambda: self.validation_block(level, vb))
        return self.label

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--smoke', action='store_true'); ap.add_argument('--resume', type=Path); ap.add_argument('--list', action='store_true')
    ap.add_argument('--boards', default='rp2040_1,rp2040_2'); ap.add_argument('--sets', default=','.join(map(str, SET_ORDER)))
    ap.add_argument('--blocks', type=int, default=BLOCKS); ap.add_argument('--reps', type=int, default=REPETITIONS)
    a = ap.parse_args()
    checked = package_check_local(); build = json.loads((ROOT / 'build-manifest.json').read_text())['build_id']
    original = json.loads((ROOT / 'original_session.json').read_text())['boards']
    wanted = {lab: original[lab] for lab in a.boards.split(',')}
    sets = tuple(int(s) for s in a.sets.split(',')); blocks = 1 if a.smoke else a.blocks; reps = 1 if a.smoke else a.reps
    say('Checking the package and looking for the RP2040 boards...')
    found = {}
    for lab, uid in wanted.items():
        f = discover(build, uid, timeout=10); found.update(f)
        say(f"  {lab} = {uid}: {'found on ' + f[uid]['port'] if uid in f else 'NOT FOUND'}")
    missing = [lab for lab, uid in wanted.items() if uid not in found]
    if missing: raise RuntimeError(f'Board(s) not found: {missing}. Flash firmware/rp2040_campaign.uf2 (hold BOOTSEL while plugging in, copy the file), use data cables, close serial monitors, then start again.')
    if a.list: return
    frozen = ROOT / 'frozen_rule.json'
    frozen_sha = digest(frozen) if frozen.exists() else None
    if a.resume:
        session = a.resume.resolve(); manifest = json.loads((session / 'session.json').read_text())
        if manifest['smoke'] != a.smoke: raise RuntimeError('Resume run type differs from the original session')
    else:
        session = ROOT / 'results' / (('smoke_' if a.smoke else 'validation_') + datetime.datetime.now().strftime('%Y%m%d_%H%M%S') + '_' + uuid.uuid4().hex[:8])
        session.mkdir(parents=True, exist_ok=False)
        manifest = {'created_utc': utc(), 'package_files_checked': checked, 'build': build, 'smoke': a.smoke, 'boards': wanted,
                    'platform': platform.platform(), 'python': sys.version, 'sets': list(sets), 'blocks_per_set': blocks, 'repetitions': reps,
                    'first_boot_block_number': FIRST_BLOCK, 'expected_main_per_board': len(sets) * blocks * 10 * 5 * reps,
                    'frozen_rule_sha256': frozen_sha, 'original_session': 'campaign_20260908_191304_56ba3992',
                    'scope': 'validation blocks for the frozen calibration-coverage rule; same keys and messages, fresh randomness, counting mode'}
        save_json(session / 'session.json', manifest)
    lock = session / 'RUNNING.lock'
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        raise RuntimeError('Session is locked. If its old window has closed, rename RUNNING.lock to STALE.lock before resuming.')
    os.write(fd, str(os.getpid()).encode()); os.close(fd)
    save_json(ROOT / 'last-validation-session.json', {'path': str(session), 'smoke': a.smoke})
    say(f'Results: {session}')
    say(f'Frozen rule: {frozen_sha}')
    say('Leave this window open. Ctrl+C stops the run and preserves its partial data.')
    failed = {}
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            futures = {pool.submit(ValidationWorker(session, lab, uid, build, a.smoke, sets, blocks, reps).run): lab for lab, uid in manifest['boards'].items()}
            try:
                for future in concurrent.futures.as_completed(futures):
                    lab = futures[future]
                    try: future.result()
                    except BaseException as e: failed[lab] = str(e); say(f'{lab} STOPPED: {e}. The other board continues.')
            except KeyboardInterrupt:
                STOP.set(); say('Stopping after any currently executing signature finishes.')
                for future, lab in futures.items():
                    try: future.result()
                    except BaseException as e: failed[lab] = str(e)
        save_json(session / 'completion.json', {'status': 'INCOMPLETE' if failed else 'COMPLETE', 'ended_utc': utc(), 'errors': failed, 'smoke': a.smoke})
    finally:
        lock.unlink(missing_ok=True)
    if failed: raise RuntimeError('A board stopped. See results; fix the cause and run again with --resume <session>.')
    say('SMOKE CHECK COMPLETE.' if a.smoke else f'VALIDATION COMPLETE: {manifest["expected_main_per_board"]:,} main signatures per board.')

if __name__ == '__main__':
    try: main()
    except Exception as exc:
        print(f'\nSTOPPED: {exc}', file=sys.stderr, flush=True); sys.exit(1)
