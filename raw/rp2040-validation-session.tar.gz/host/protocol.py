"""CRC-framed USB CDC protocol. Save received bytes before interpreting them."""
import json, time, zlib
class ProtocolError(RuntimeError): pass

def encode(payload):
    data=payload.encode('ascii')
    return data+b'\t'+f'{zlib.crc32(data):08x}'.encode()+b'\n'

def decode(line):
    try:
        payload,checksum=line.rstrip(b'\r\n').rsplit(b'\t',1)
        if len(checksum)!=8 or zlib.crc32(payload)!=int(checksum,16):
            raise ValueError('CRC mismatch')
        return json.loads(payload)
    except (ValueError,UnicodeError) as e:
        raise ProtocolError(f'Invalid device frame: {e}') from e

class Link:
    def __init__(self,serial,raw=None,commands=None):
        self.serial=serial; self.raw=raw; self.commands=commands
        self.buffer=bytearray(); self.seq=0
    def request(self,command,*args,timeout=300):
        self.seq+=1
        frame=encode(' '.join(map(str,(command,self.seq,*args))))
        if self.commands:
            # Commands contain benchmark test keys and recorded test randomness.
            self.commands.write(frame); self.commands.flush()
        if self.serial.write(frame)!=len(frame): raise ProtocolError('Short USB write')
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            if b'\n' in self.buffer:
                line,_,rest=self.buffer.partition(b'\n'); self.buffer=bytearray(rest)
                if not line.strip(): continue
                row=decode(line)
                if row.get('id')!=self.seq: raise ProtocolError('Unexpected or duplicate response sequence')
                if row.get('type')=='error': raise ProtocolError(str(row))
                return row
            chunk=self.serial.read(max(1,min(getattr(self.serial,'in_waiting',0),4096)))
            if chunk:
                if self.raw: self.raw.write(chunk); self.raw.flush()
                self.buffer.extend(chunk)
                if len(self.buffer)>40000: raise ProtocolError('Device frame exceeds 40,000 bytes')
        raise ProtocolError(f'No complete response to {command} after {timeout}s; invocation status is unknown')
    def close(self): self.serial.close()
