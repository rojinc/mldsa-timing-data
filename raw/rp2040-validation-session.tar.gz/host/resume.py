import json, sys
from campaign import ROOT, main
last=json.loads((ROOT/'last-session.json').read_text())
sys.argv=['campaign.py','--resume',last['path']]+(['--smoke'] if last['smoke'] else [])
try: main()
except Exception as e: print(f'RESUME STOPPED: {e}'); sys.exit(1)
