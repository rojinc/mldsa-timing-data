"""Run the controlled RP2040 signing campaign. No third-party analysis packages."""
from pathlib import Path
import argparse, concurrent.futures, csv, ctypes, datetime, hashlib, json, os, platform
import random, secrets, shutil, statistics, sys, threading, time, traceback, uuid
from protocol import Link, ProtocolError
ROOT=Path(__file__).resolve().parent.parent
LEVELS=(44,65,87)
SIZES={44:(1312,2560,2420),65:(1952,4032,3309),87:(2592,4896,4627)}
PRINT_LOCK=threading.Lock()
STOP=threading.Event()
def say(s):
    with PRINT_LOCK: print(s,flush=True)
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save_json(path,value):
    path=Path(path); tmp=path.with_suffix(path.suffix+'.tmp')
    with tmp.open('w',encoding='utf-8',newline='\n') as f:
        json.dump(value,f,indent=2); f.write('\n'); f.flush(); os.fsync(f.fileno())
    os.replace(tmp,path)
def package_check(root=ROOT):
    path=root/'CHECKSUMS.json'
    if not path.exists(): raise RuntimeError('Missing CHECKSUMS.json; use the assembled Windows package')
    expected=json.loads(path.read_text())
    for name,sha in expected.items():
        if digest(root/name)!=sha: raise RuntimeError(f'Package checksum mismatch: {name}')
    return digest(path)

def validate_randomness(attempt,session):
    record=json.loads((attempt/'randomness.json').read_text())
    path=(session/record['file']).resolve()
    if not path.is_relative_to(session.resolve()): raise RuntimeError('Randomness path leaves the session')
    if path.stat().st_size!=32*record['count'] or digest(path)!=record['sha256']:
        raise RuntimeError('Recorded randomness has changed')
def open_port(name):
    import serial
    port=serial.Serial(port=None,baudrate=115200,timeout=.2,write_timeout=10)
    port.port=name; port.dtr=True; port.rts=False; port.open()
    return port

def discover(build,expected_uid=None,timeout=10):
    from serial.tools import list_ports
    deadline=time.monotonic()+timeout
    while True:
        found={}
        for port in list_ports.comports():
            # Do not probe ESP32 ports or unrelated USB serial adapters.
            if port.vid!=0x2e8a or port.pid!=0x000a: continue
            if expected_uid and port.serial_number and port.serial_number.lower()!=expected_uid.lower(): continue
            link=None
            try:
                link=Link(open_port(port.device)); row=link.request('HELLO',timeout=2)
                validate_hello(row,build)
                if expected_uid and row['uid']!=expected_uid: continue
                found[row['uid']]={'port':port.device,'hello':row}
            except (OSError,RuntimeError): pass
            finally:
                if link: link.close()
        if (expected_uid and expected_uid in found) or (not expected_uid and len(found)>=2): return found
        if time.monotonic()>=deadline: return found
        time.sleep(.5)
def validate_hello(row,build):
    if row.get('type')!='hello' or row.get('protocol')!=1 or row.get('build')!=build or row.get('clock_hz')!=125000000 or row.get('core')!=0:
        raise ProtocolError('Unexpected firmware or clock; flash the UF2 from this package')
    if not isinstance(row.get('uid'),str) or len(row['uid'])!=16 or any(c not in '0123456789abcdefABCDEF' for c in row['uid']): raise ProtocolError('Missing hardware identity')

def schedule(seed,repetitions=200):
    rows=[(k,m,r) for k in range(10) for m in range(5) for r in range(repetitions)]
    random.Random(seed).shuffle(rows)
    return rows

def validate_result(row,level,key,mode,nonce):
    if level not in SIZES or type(key) is not int or key not in range(10) or type(mode) is not int or mode not in range(3):
        raise ProtocolError('Invalid parameter set, key or mode')
    if any(row.get(k)!=v for k,v in {'type':'result','set':level,'key':key,'mode':mode,'boot_nonce':nonce,'rc':0,'verify_rc':0,'rng_ok':1,'stack_guard':1,'siglen':SIZES[level][2]}.items()):
        raise ProtocolError('Signature, RNG, stack, identity, or reset validation failed')
    if any(type(row.get(k)) is not int or row[k]<0 for k in ('start_us','sign_us','verify_us','K','pack_start_us','pack_end_us')) or row['sign_us']==0 or row['verify_us']==0:
        raise ProtocolError('Invalid device timer or counter')
    if not isinstance(row.get('sha256'),str) or len(row['sha256'])!=64 or any(c not in '0123456789abcdef' for c in row['sha256']): raise ProtocolError('Missing signature digest')
    if not isinstance(row.get('reject'),list) or len(row['reject'])!=4 or any(type(n) is not int or n<0 for n in row['reject']):
        raise ProtocolError('Invalid rejection counters')
    if not isinstance(row.get('events'),list): raise ProtocolError('Invalid event list')
    if mode!=2 and (row['events'] or row['pack_start_us'] or row['pack_end_us']):
        raise ProtocolError('Non-stage mode contains stage instrumentation')
    if mode:
        if row['K']!=1+sum(row['reject']) or len(row['reject'])!=4 or any(n<0 for n in row['reject']):
            raise ProtocolError('K != 1 + z + w0 + ct0 + hint')
    elif row['K']!=0 or any(row['reject']) or row['events']: raise ProtocolError('Plain mode contains instrumentation')
    if row['event_overflow']: raise ProtocolError('Stage buffer overflow; result retained, phase is incomplete')
    if mode==2:
        events=row['events']
        if len(events)!=row['K'] or events[-1][-1]!=0: raise ProtocolError('Incomplete candidate trace')
        rejection=[0]*4; previous_end=0
        for index,event in enumerate(events):
            if not isinstance(event,list) or len(event)!=7 or any(type(n) is not int or n<0 for n in event): raise ProtocolError('Invalid stage event')
            reason=event[6]
            if reason not in range(5) or (reason==0)!=(index==len(events)-1): raise ProtocolError('Invalid stage outcome')
            if reason: rejection[reason-1]+=1
            if reason and any(event[reason+1:5]): raise ProtocolError('Unreached stage has a timestamp')
            reached=event[:(reason or 4)+1]+[event[5]]
            if reached!=sorted(reached) or event[0]<previous_end: raise ProtocolError('Stage times are not ordered')
            previous_end=event[5]
        if rejection!=row['reject']: raise ProtocolError('Stage outcomes disagree with counters')
        if not previous_end<=row['pack_start_us']<=row['pack_end_us']<=row['sign_us']:
            raise ProtocolError('Invalid signature packing timestamps')

def percentile(values,p):
    ordered=sorted(values); pos=(len(ordered)-1)*p; i=int(pos); f=pos-i
    return ordered[i]*(1-f)+ordered[min(i+1,len(ordered)-1)]*f

def overhead_report(pairs):
    ratios=[(c-p)/p for p,c in pairs]
    return {'pairs':len(pairs),'median_relative_overhead':statistics.median(ratios),
            'p95_relative_overhead':percentile(ratios,.95),
            'passed':abs(statistics.median(ratios))<=.02 and abs(percentile(ratios,.95))<=.05}

class Attempt:
    def __init__(self,parent,phase):
        self.path=parent/(phase+'_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8])
        self.path.mkdir(parents=True,exist_ok=False)
        self.raw=(self.path/'raw.bin').open('xb',buffering=0)
        self.commands=(self.path/'commands.bin').open('xb',buffering=0)
        self.rows=(self.path/'results.jsonl').open('x',encoding='utf-8',buffering=1)
        self.count=0; self.started=utc(); self.phase=phase
        save_json(self.path/'status.json',{'status':'RUNNING','started_utc':self.started,'phase':phase})
    def record(self,row):
        self.rows.write(json.dumps(row,separators=(',',':'))+'\n'); self.rows.flush(); self.count+=1
        if self.count%100==0: os.fsync(self.rows.fileno())
    def finish(self,status,**extra):
        self.rows.flush(); os.fsync(self.rows.fileno())
        for f in (self.raw,self.commands,self.rows): f.close()
        save_json(self.path/'status.json',{'artifacts':{p.name:digest(p) for p in self.path.iterdir() if p.is_file() and p.name!='status.json'},'status':status,'phase':self.phase,'started_utc':self.started,'ended_utc':utc(),'rows':self.count,'raw_sha256':digest(self.path/'raw.bin'),'results_sha256':digest(self.path/'results.jsonl'),**extra})

class Worker:
    def __init__(self,session,label,uid,build,smoke=False):
        self.session=session; self.label=label; self.uid=uid; self.build=build; self.smoke=smoke
        self.parent=session/label; self.parent.mkdir(exist_ok=True)
        self.state_path=self.parent/'progress.json'
        self.state=json.loads(self.state_path.read_text()) if self.state_path.exists() else {'completed':{}}
        self.fixture=ROOT/'fixtures'; self.messages=(self.fixture/'messages.bin').read_bytes()
        self.link=None; self.key=None; self.attempt=None
    def connect(self,timeout=45):
        found=discover(self.build,self.uid,timeout)
        if self.uid not in found: raise RuntimeError(f'{self.label}: board {self.uid} not found; check USB cable and firmware')
        self.link=Link(open_port(found[self.uid]['port']),self.attempt.raw,self.attempt.commands)
        h=self.link.request('HELLO',timeout=3); validate_hello(h,self.build)
        if h['uid']!=self.uid: raise ProtocolError('Board identity changed')
        return h
    def reset(self):
        old=self.connect(); nonce=secrets.randbelow(0xfffffffe)+1
        while nonce==old['boot_nonce']: nonce=secrets.randbelow(0xfffffffe)+1
        reply=self.link.request('RESET',nonce,timeout=3)
        if reply.get('type')!='reset' or reply.get('nonce')!=nonce: raise ProtocolError('Reset acknowledgement mismatch')
        self.link.close(); self.link=None; time.sleep(1.5)
        new=self.connect()
        if new['boot_nonce']!=nonce or not new['watchdog_reset']: raise ProtocolError('A real watchdog reset was not confirmed')
        self.nonce=nonce; self.key=None; self.previous_start=-1
        save_json(self.attempt.path/'device.json',{'before_reset':old,'after_reset':new})
    def select(self,level,key):
        if self.key==(level,key): return
        row=self.link.request('KEY',level,key,timeout=10)
        if row.get('type')!='key' or row.get('set')!=level or row.get('key')!=key: raise ProtocolError('Key acknowledgement mismatch')
        self.key=(level,key)
    def randoms(self,level,phase,count):
        folder=self.session/'randomness'; folder.mkdir(exist_ok=True)
        p=folder/f'{self.label}_{level}_{phase}.bin'
        stamp=p.with_suffix('.json')
        if not p.exists() and not stamp.exists():
            # A separate OS-generated stream for each board, set and phase.
            with p.open('xb') as f: f.write(secrets.token_bytes(count*32)); f.flush(); os.fsync(f.fileno())
            save_json(stamp,{'sha256':digest(p),'count':count})
        if not stamp.exists() or not p.exists() or digest(p)!=json.loads(stamp.read_text())['sha256']:
            raise RuntimeError('Randomness stream is incomplete or changed; preserve it and start a new session')
        b=p.read_bytes()
        if len(b)!=count*32: raise RuntimeError('Randomness file size mismatch')
        save_json(self.attempt.path/'randomness.json',{'file':str(p.relative_to(self.session)),'sha256':digest(p),'count':count})
        return [b[i:i+32] for i in range(0,len(b),32)]
    def sign(self,level,key,message,mode,rnd,index,phase,full_signature=False,**fields):
        if STOP.is_set(): raise RuntimeError('Stopped by user; in-progress block remains incomplete')
        self.select(level,key)
        msg=self.messages[message*128:(message+1)*128]
        started=time.monotonic()
        row=self.link.request('SIGN',mode,msg.hex(),rnd.hex())
        # Preserve a failing result before validating it.
        row.update(host_utc=utc(),host_response_s=time.monotonic()-started,board=self.label,uid=self.uid,phase=phase,index=index,message=message,**fields)
        self.attempt.record(row)
        validate_result(row,level,key,mode,self.nonce)
        if row['start_us']<=self.previous_start: raise ProtocolError('Device timer reset or repeated result')
        self.previous_start=row['start_us']
        if full_signature:
            s=self.link.request('SIG'); raw=bytes.fromhex(s['hex'])
            if s.get('type')!='signature' or len(raw)!=SIZES[level][2] or hashlib.sha256(raw).hexdigest()!=row['sha256']:
                raise ProtocolError('Downloaded signature digest mismatch')
            return row,raw
        return row
    def expected_rows(self,name):
        if name.endswith('_pilot'): return 126 if self.smoke else 2500
        if name.endswith('_stages'): return 110 if self.smoke else 1100
        if '_block' in name: return 150 if self.smoke else 10100
        raise ValueError('Unknown phase name')
    def do_phase(self,name,run):
        if name in self.state['completed']:
            old=self.parent/self.state['completed'][name]
            status=json.loads((old/'status.json').read_text())
            if any(digest(old/name)!=sha for name,sha in status['artifacts'].items()):
                raise RuntimeError('Completed phase artifact changed')
            if status['rows']!=self.expected_rows(name): raise RuntimeError('Completed phase has the wrong row count')
            if status['status']!='COMPLETE' or digest(old/'results.jsonl')!=status['results_sha256'] or digest(old/'raw.bin')!=status['raw_sha256']:
                raise RuntimeError('Previously completed block failed integrity validation')
            validate_randomness(old,self.session)
            say(f'{self.label}: keeping completed {name}')
            return
        self.attempt=Attempt(self.parent,name)
        try:
            self.reset(); run()
            if self.attempt.count!=self.expected_rows(name): raise RuntimeError('Phase ended with the wrong invocation count')
            self.attempt.finish('COMPLETE')
            self.state['completed'][name]=self.attempt.path.name; save_json(self.state_path,self.state)
            say(f'{self.label}: {name} COMPLETE ({self.attempt.count:,} recorded invocations)')
        except BaseException as e:
            self.attempt.finish('INCOMPLETE',error=str(e),traceback=traceback.format_exc(),pending_invocation='See final command and raw response. Do not infer a completed observation from a host timeout.')
            raise
        finally:
            if self.link: self.link.close(); self.link=None
    def warmup(self,level,rnd):
        for i,r in enumerate(rnd): self.sign(level,i%10,(i//10)%5,0,r,i,'warmup')
    def pilot(self,level):
        n=10 if self.smoke else 1000; reverse=2 if self.smoke else 100; stages=2 if self.smoke else 200
        rng=self.randoms(level,'pilot',100+n+reverse)
        self.warmup(level,rng[:100]); pairs=[]
        for i in range(n+reverse):
            key=i%10; message=(i//10)%5; pair={}; signatures={}
            # Main pairs use plain then counts; final repeat uses the reverse order.
            order=(0,1) if i<n else (1,0)
            for mode in order:
                row,sig=self.sign(level,key,message,mode,rng[100+i],i,'pilot',True,pair_order='PC' if i<n else 'CP')
                pair[mode]=row; signatures[mode]=sig
            if signatures[0]!=signatures[1]: raise ProtocolError('Plain/counts signature bytes differ')
            if i<stages:
                stage,sig=self.sign(level,key,message,2,rng[100+i],i,'pilot_stages',True)
                if sig!=signatures[0] or stage['K']!=pair[1]['K'] or stage['reject']!=pair[1]['reject']:
                    raise ProtocolError('Stage/plain signature or counter mismatch')
            pairs.append((pair[0]['sign_us'],pair[1]['sign_us']))
            if (i+1)%100==0: say(f'{self.label}: set {level} pilot {i+1}/{n+reverse} pairs')
        report=overhead_report(pairs); report['smoke_only']=self.smoke
        report['forward']=overhead_report(pairs[:n]); report['reverse']=overhead_report(pairs[n:])
        report['passed']=all(report[group]['passed'] for group in ('forward','reverse')) and report['passed']
        save_json(self.attempt.path/'pilot_report.json',report)
        if not report['passed'] and not self.smoke: raise RuntimeError('Pilot overhead exceeded the 2% median / 5% p95 gates; inspect pilot_report.json before collecting main data')
    def main_block(self,level,block):
        count=50 if self.smoke else 10000
        rng=self.randoms(level,f'block{block}',100+count)
        seedfile=self.session/f'{self.label}_{level}_block{block}_schedule.json'
        if not seedfile.exists(): save_json(seedfile,{'seed':secrets.randbits(64),'repetitions':1 if self.smoke else 200})
        config=json.loads(seedfile.read_text()); rows=schedule(config['seed'],config['repetitions'])
        if len(rows)!=count: raise RuntimeError('Schedule count mismatch')
        with (self.attempt.path/'schedule.csv').open('x',newline='') as f:
            w=csv.writer(f); w.writerow(['index','key','message','repetition','partition'])
            for i,(key,msg,rep) in enumerate(rows): w.writerow([i,key,msg,rep,self.partition(key,block)])
        self.warmup(level,rng[:100]); start=time.monotonic()
        for i,(key,msg,rep) in enumerate(rows):
            self.sign(level,key,msg,1,rng[100+i],i,'main',boot_block=block,repetition=rep,partition=self.partition(key,block))
            if (i+1)%100==0:
                remain=(time.monotonic()-start)/(i+1)*(count-i-1)/60
                say(f'{self.label}: set {level}, boot {block+1}/5, {i+1:,}/{count:,}; this block about {remain:.0f} min remaining')
    @staticmethod
    def partition(key,block):
        return 'calibration' if key<8 and block<3 else 'unseen_key' if block<3 else 'unseen_boot' if key<8 else 'unseen_key_and_boot'
    def stages(self,level):
        n=10 if self.smoke else 1000; rng=self.randoms(level,'stages',100+n); self.warmup(level,rng[:100])
        for i in range(n):
            self.sign(level,i%10,(i//10)%5,2,rng[100+i],i,'diagnostic',partition='diagnostic_calibration' if i%10<5 else 'diagnostic_holdout')
            if (i+1)%100==0: say(f'{self.label}: set {level} stage diagnostics {i+1}/{n}')
    def run(self):
        for level in LEVELS:
            self.do_phase(f'set{level}_pilot',lambda:self.pilot(level))
            if self.smoke: continue
            for block in range(5): self.do_phase(f'set{level}_block{block}',lambda:self.main_block(level,block))
            self.do_phase(f'set{level}_stages',lambda:self.stages(level))
        return self.label

def prevent_sleep(enable):
    if sys.platform=='win32':
        if not ctypes.windll.kernel32.SetThreadExecutionState(0x80000003 if enable else 0x80000000):
            raise RuntimeError('Windows could not register the stay-awake request')

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--smoke',action='store_true'); ap.add_argument('--resume',type=Path); ap.add_argument('--list',action='store_true')
    a=ap.parse_args(); check=package_check(); build=json.loads((ROOT/'build-manifest.json').read_text())['build_id']
    say('Checking the package and looking for the 2 RP2040 boards...')
    found=discover(build)
    for uid,info in sorted(found.items()): say(f"  {uid}: {info['port']}")
    if len(found)!=2: raise RuntimeError(f'Found {len(found)} matching boards. Connect exactly 2 flashed RP2040 boards using data cables, then start again.')
    if a.list: return
    if a.resume:
        session=a.resume.resolve(); manifest=json.loads((session/'session.json').read_text())
        if manifest['package_checksum']!=check or manifest['smoke']!=a.smoke: raise RuntimeError('Resume package or run type differs from the original session')
        if set(manifest['boards'].values())!=set(found): raise RuntimeError('Resume requires the original 2 hardware IDs')
    else:
        session=ROOT/'results'/(("smoke_" if a.smoke else "campaign_")+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8])
        session.mkdir(parents=True,exist_ok=False)
        manifest={'created_utc':utc(),'package_checksum':check,'build':build,'smoke':a.smoke,'boards':{f'rp2040_{i+1}':uid for i,uid in enumerate(sorted(found))},'platform':platform.platform(),'python':sys.version,'expected_main_per_board':0 if a.smoke else 150000,'scope':'signing pilot, controlled main campaign, stage diagnostics; telemetry is a separate workload experiment'}
        save_json(session/'session.json',manifest)
    lock=session/'RUNNING.lock'
    try:
        fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    except FileExistsError: raise RuntimeError('Session is locked. If its old window has closed, rename RUNNING.lock to STALE.lock before resuming.')
    os.write(fd,str(os.getpid()).encode()); os.close(fd)
    save_json(ROOT/'last-session.json',{'path':str(session),'smoke':a.smoke})
    say(f'Results: {session}')
    for label,uid in manifest['boards'].items(): say(f'{label} = {uid}. Keep this assignment when reporting results.')
    say('Leave this window open. Ctrl+C stops the run and preserves its partial data.')
    failed={}
    try:
        prevent_sleep(True)
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            futures={pool.submit(Worker(session,label,uid,build,a.smoke).run):label for label,uid in manifest['boards'].items()}
            try:
                for future in concurrent.futures.as_completed(futures):
                    label=futures[future]
                    try: future.result()
                    except BaseException as e: failed[label]=str(e); say(f'{label} STOPPED: {e}. The other board continues.')
            except KeyboardInterrupt:
                STOP.set(); say('Stopping after any currently executing signature finishes. Preserve this window until the stop completes.')
                for future,label in futures.items():
                    try: future.result()
                    except BaseException as e: failed[label]=str(e)
        save_json(session/'completion.json',{'status':'INCOMPLETE' if failed else 'COMPLETE','ended_utc':utc(),'errors':failed,'smoke':a.smoke})
    finally:
        prevent_sleep(False); lock.unlink(missing_ok=True)
    if failed: raise RuntimeError('A board stopped. See results and use RESUME.cmd after fixing the cause.')
    say('SMOKE CHECK COMPLETE. Start the full campaign with START.cmd.' if a.smoke else 'CAMPAIGN COMPLETE: 150,000 main signatures per board, plus pilot, warmups and diagnostics. Run ANALYZE.cmd.')

if __name__=='__main__':
    try: main()
    except Exception as exc:
        print(f'\nSTOPPED: {exc}',file=sys.stderr,flush=True); sys.exit(1)
