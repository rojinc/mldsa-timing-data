"""Copy the packaged UF2 to an attached RP2040 BOOTSEL volume on Windows."""
from pathlib import Path
import shutil, string, sys
from campaign import ROOT, package_check

def main():
    package_check()
    if sys.platform!='win32': raise RuntimeError('Use this launcher on Windows')
    drives=[]
    for letter in string.ascii_uppercase:
        drive=Path(letter+':/'); info=drive/'INFO_UF2.TXT'
        try:
            text=info.read_text(errors='replace')
            if 'Board-ID: RPI-RP2' in text: drives.append(drive)
        except OSError: pass
    if not drives: raise RuntimeError('No RP2040 BOOTSEL drive found. Hold BOOTSEL while connecting a board, release it, then run FLASH.cmd again.')
    for drive in drives:
        print(f'Copying campaign firmware to {drive}',flush=True)
        # BOOTSEL remounts the board automatically after accepting the UF2.
        shutil.copyfile(ROOT/'firmware/rp2040_campaign.uf2',drive/'rp2040_campaign.uf2')
    print('Copy complete. The drive disappears when the board reboots. Flash the 2nd board the same way, then run CHECK_BOARDS.cmd.')
if __name__=='__main__':
    try: main()
    except Exception as e: print(f'FLASH STOPPED: {e}'); sys.exit(1)
