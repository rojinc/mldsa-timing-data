"""Validate completed blocks and produce analysis-ready CSVs and basic summaries."""
from pathlib import Path
import collections, csv, json, math, statistics, sys
from campaign import ROOT, SIZES, LEVELS, Worker, digest, save_json, validate_result, validate_hello, validate_randomness, overhead_report

def validate_pilot(rows):
    warm=[r for r in rows if r['phase']=='warmup']
    pairs=[r for r in rows if r['phase']=='pilot']
    stages=[r for r in rows if r['phase']=='pilot_stages']
    if len(rows)!=2500 or len(warm)!=100 or len(pairs)!=2200 or len(stages)!=200:
        raise ValueError('Pilot invocation counts differ from the protocol')
    if [r['index'] for r in warm]!=list(range(100)) or any(r['mode']!=0 for r in warm):
        raise ValueError('Invalid pilot warmups')
    timings=[]
    for i in range(1100):
        a,b=pairs[2*i:2*i+2]; order=(0,1) if i<1000 else (1,0)
        if (a['mode'],b['mode'])!=order or any(r['index']!=i or r['key']!=i%10 or r['message']!=(i//10)%5 for r in (a,b)):
            raise ValueError('Invalid pilot pairing')
        if a['sha256']!=b['sha256']: raise ValueError('Pilot signature mismatch')
        plain,counts=(a,b) if i<1000 else (b,a)
        timings.append((plain['sign_us'],counts['sign_us']))
        if i<200:
            stage=stages[i]
            if stage['index']!=i or stage['mode']!=2 or any(stage[k]!=counts[k] for k in ('key','message','sha256','K','reject')):
                raise ValueError('Pilot stage comparison mismatch')
    reports=[overhead_report(p) for p in (timings,timings[:1000],timings[1000:])]
    if not all(r['passed'] for r in reports): raise ValueError('Recomputed pilot overhead gate failed')

def validate_attempt(path,level,phase):
    status=json.loads((path/'status.json').read_text())
    if any(digest(path/name)!=sha for name,sha in status['artifacts'].items()): raise ValueError('Phase artifact changed')
    if status['status']!='COMPLETE': raise ValueError(f'{path.name}: incomplete')
    if digest(path/'results.jsonl')!=status['results_sha256'] or digest(path/'raw.bin')!=status['raw_sha256']:
        raise ValueError(f'{path.name}: changed data')
    device=json.loads((path/'device.json').read_text())['after_reset']
    rows=[]; last=-1
    for line in (path/'results.jsonl').read_text().splitlines():
        row=json.loads(line); validate_result(row,level,row['key'],row['mode'],device['boot_nonce'])
        if row['start_us']<=last: raise ValueError('Device clock is not increasing')
        last=row['start_us']; rows.append(row)
    if len(rows)!=status['rows']: raise ValueError('Row count differs from status')
    if phase=='main':
        warm=[r for r in rows if r['phase']=='warmup']; main=[r for r in rows if r['phase']=='main']
        if len(rows)!=10100 or len(warm)!=100 or len(main)!=10000: raise ValueError('Expected 100 warmups and 10,000 main invocations')
        if any(r['mode']!=0 for r in warm) or [r['index'] for r in warm]!=list(range(100)):
            raise ValueError('Invalid warmup modes or indices')
        with (path/'schedule.csv').open(newline='') as f:
            expected=list(csv.DictReader(f))
        if len(expected)!=10000: raise ValueError('Schedule length mismatch')
        for i,(row,want) in enumerate(zip(main,expected)):
            if row['index']!=i or row['mode']!=1 or any(str(row[field])!=want[field] for field in ('key','message','repetition','partition')):
                raise ValueError('Result does not match the recorded schedule')
        counts=collections.Counter((r['key'],r['message']) for r in main)
        if len(counts)!=50 or set(counts.values())!={200}: raise ValueError('Unbalanced key/message schedule')
        if len({(r['key'],r['message'],r['repetition']) for r in main})!=10000 or any(r['repetition'] not in range(200) for r in main):
            raise ValueError('Missing or repeated schedule repetition')
        return main
    return rows

def analyze(session):
    meta=json.loads((session/'session.json').read_text())
    if meta['smoke']: raise ValueError('Smoke checks are not manuscript measurements')
    summaries=[]; rejected=[]
    output=session/'analysis'; output.mkdir(exist_ok=True)
    for board,uid in meta['boards'].items():
        statefile=session/board/'progress.json'
        done=json.loads(statefile.read_text())['completed'] if statefile.exists() else {}
        for level in LEVELS:
            pilot_valid=False
            pilot=f'set{level}_pilot'
            if pilot not in done: rejected.append(f'{board}/{pilot}: missing')
            else:
                path=session/board/done[pilot]
                try:
                    pilotrows=validate_attempt(path,level,'pilot')
                    validate_randomness(path,session)
                    pilot_device=json.loads((path/'device.json').read_text())['after_reset']
                    validate_hello(pilot_device,meta['build'])
                    if pilot_device['uid']!=uid or not pilot_device['watchdog_reset'] or any(r['uid']!=uid or r['board']!=board for r in pilotrows):
                        raise ValueError('Pilot board identity or reset mismatch')
                    if len(pilotrows)!=2500 or not json.loads((path/'pilot_report.json').read_text())['passed']:
                        raise ValueError('Pilot counts or overhead gate failed')
                    validate_pilot(pilotrows)
                    pilot_valid=True
                except (OSError,ValueError,RuntimeError,KeyError,TypeError) as e: rejected.append(f'{board}/{pilot}: {e}')
            allrows=[]; nonces=set(); valid_blocks=0
            for block in range(5):
                name=f'set{level}_block{block}'
                if name not in done: rejected.append(f'{board}/{name}: no completed attempt'); continue
                path=session/board/done[name]
                try:
                    if not pilot_valid: raise ValueError('Excluded because the pilot did not pass validation')
                    rows=validate_attempt(path,level,'main')
                    validate_randomness(path,session)
                    device=json.loads((path/'device.json').read_text())['after_reset']
                    validate_hello(device,meta['build'])
                    if device['uid']!=uid or not device['watchdog_reset']: raise ValueError('Wrong board or reset metadata')
                    nonce=rows[0]['boot_nonce']
                    if nonce in nonces: raise ValueError('Boot nonce reused across blocks')
                    if any(r['uid']!=uid or r['board']!=board or r['boot_block']!=block for r in rows): raise ValueError('Board or block identity mismatch')
                    if any(r['partition']!=Worker.partition(r['key'],block) for r in rows): raise ValueError('Holdout partition mismatch')
                    nonces.add(nonce); allrows+=rows; valid_blocks+=1
                except (OSError,ValueError,RuntimeError,KeyError,TypeError) as e: rejected.append(f'{board}/{name}: {e}')
            fields=['board','uid','set','boot_block','key','message','repetition','partition','index','start_us','sign_us','verify_us','K','n_z','n_w0','n_ct0','n_hint','sha256']
            with (output/f'{board}_set{level}.csv').open('w',newline='') as f:
                w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
                for row in allrows:
                    r={k:row[k] for k in fields if k in row}
                    r.update(zip(('n_z','n_w0','n_ct0','n_hint'),row['reject'])); w.writerow(r)
            if allrows:
                k=[r['K'] for r in allrows]; t=[r['sign_us']/1000 for r in allrows]; mean=statistics.mean(k)
                se=statistics.stdev(k)/math.sqrt(len(k)) if len(k)>1 else 0
                summaries.append({'board':board,'set':level,'valid_boot_blocks':valid_blocks,'n':len(k),'mean_K':mean,'mean_K_normal_CI_lower':mean-1.96*se,'mean_K_normal_CI_upper':mean+1.96*se,'p_hat':1/mean,'sign_mean_ms':statistics.mean(t),'sign_min_ms':min(t),'sign_max_ms':max(t),'status':'COMPLETE' if valid_blocks==5 else 'PARTIAL'})
            # Preserve stage events in a flat CSV for source-level cost analysis.
            diag=f'set{level}_stages'
            with (output/f'{board}_set{level}_stages.csv').open('w',newline='') as f:
                w=csv.writer(f); w.writerow(['board','set','invocation','key','message','partition','attempt','reason','entry_us','z_check_us','w0_check_us','ct0_check_us','hint_check_us','exit_us','attempt_us'])
                try:
                    if diag not in done: raise ValueError('missing')
                    if not pilot_valid: raise ValueError('Excluded because the pilot did not pass validation')
                    path=session/board/done[diag]
                    rows=validate_attempt(path,level,'stages')
                    validate_randomness(path,session)
                    device=json.loads((path/'device.json').read_text())['after_reset']
                    validate_hello(device,meta['build'])
                    if device['uid']!=uid or not device['watchdog_reset'] or device['boot_nonce'] in nonces:
                        raise ValueError('Stage board or reset mismatch')
                    if any(r['uid']!=uid or r['board']!=board for r in rows): raise ValueError('Stage row identity mismatch')
                    diagnostics=[r for r in rows if r['phase']=='diagnostic']
                    warm=[r for r in rows if r['phase']=='warmup']
                    if len(rows)!=1100 or len(warm)!=100 or [r['index'] for r in warm]!=list(range(100)) or any(r['mode']!=0 for r in warm):
                        raise ValueError('Stage warmup count or mode mismatch')
                    if len(diagnostics)!=1000 or [r['index'] for r in diagnostics]!=list(range(1000)) or any(r['mode']!=2 for r in diagnostics):
                        raise ValueError('Stage diagnostic count or index mismatch')
                    if any(r['key']!=r['index']%10 or r['message']!=(r['index']//10)%5 or r['partition']!=('diagnostic_calibration' if r['key']<5 else 'diagnostic_holdout') for r in diagnostics):
                        raise ValueError('Stage diagnostic schedule or partition mismatch')
                    for row in diagnostics:
                        for i,event in enumerate(row['events']):
                            w.writerow([board,level,row['index'],row['key'],row['message'],row['partition'],i+1,event[6],*event[:6],event[5]-event[0]])
                except (OSError,ValueError,RuntimeError,KeyError,TypeError) as e: rejected.append(f'{board}/{diag}: {e}')
    save_json(output/'summary.json',{'configurations':summaries,'excluded':rejected,'note':'Normal mean-K confidence intervals are descriptive. Account for key and boot grouping in manuscript inference. No latency bound is estimated here.'})
    with (output/'summary.csv').open('w',newline='') as f:
        fields=list(summaries[0]) if summaries else ['board','set','valid_boot_blocks','n','status']
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(summaries)
    save_json(output/'checksums.json',{p.name:digest(p) for p in output.iterdir() if p.is_file() and p.name!='checksums.json'})
    print(f'Analysis saved to {output}')
    if rejected:
        print('\n'.join(rejected)); raise ValueError('Analysis contains partial configurations; do not present them as complete campaigns')
    if len(summaries)!=6 or any(s['n']!=50000 for s in summaries): raise ValueError('Expected 6 configurations of 50,000 signatures')
    print('Validated all 300,000 main signing observations.')

if __name__=='__main__':
    try:
        p=Path(sys.argv[1]) if len(sys.argv)>1 else Path(json.loads((ROOT/'last-session.json').read_text())['path'])
        analyze(p)
    except Exception as e: print(f'ANALYSIS STOPPED: {e}'); sys.exit(1)
