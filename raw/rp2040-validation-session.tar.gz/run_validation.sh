#!/bin/sh
# One command for the RP2040 validation campaign (frozen calibration-coverage rule):
#   cd ~/Desktop/research/mldsa-rp2040-results-20260911/rp2040-validation && ./run_validation.sh
# 1. creates .venv with pyserial if missing (needs internet once),
# 2. verifies the frozen rule file against its recorded hash,
# 3. runs a 3-minute smoke check on both boards (50 calls per set, real resets, full validation),
# 4. starts the validation blocks (both boards in parallel, sets 65, 44, 87, 2 blocks x 5,000 calls per set)
#    only if the smoke check completed.
# Interrupted? Run again: completed blocks are kept and the session resumes.
set -u
HERE=$(cd "$(dirname "$0")" && pwd); cd "$HERE"
# Optional argument: which boards, e.g. "rp2040_1" for the unit that failed in the paper only. Default: both.
BOARDS=${1:-rp2040_1,rp2040_2}
if [ ! -x .venv/bin/python ]; then
    echo "=== creating .venv (needs internet once)"
    python3 -m venv .venv && .venv/bin/pip install -q pyserial==3.5 || { echo "venv setup failed"; exit 1; }
fi
shasum -a 256 -c frozen_rule.sha256 || { echo "frozen_rule.json does not match its recorded hash; stop"; exit 1; }
mkdir -p results
if [ -f last-validation-session.json ] && grep -q '"smoke": false' last-validation-session.json; then
    S=$(.venv/bin/python -c "import json;print(json.load(open('last-validation-session.json'))['path'])")
    if [ -d "$S" ] && [ ! -f "$S/completion.json" ] || grep -q INCOMPLETE "$S/completion.json" 2>/dev/null; then
        echo "=== resuming $S  $(date)"
        [ -f "$S/RUNNING.lock" ] && mv "$S/RUNNING.lock" "$S/STALE.lock.$(date +%s)"
        caffeinate -is .venv/bin/python host/validate_blocks.py --boards "$BOARDS" --resume "$S" 2>&1 | tee -a results/validation.log
        exit $?
    fi
fi
echo "=== smoke check  $(date)"
caffeinate -is .venv/bin/python host/validate_blocks.py --boards "$BOARDS" --smoke 2>&1 | tee results/smoke.log
if grep -q "SMOKE CHECK COMPLETE" results/smoke.log; then
    echo "=== smoke check complete: starting the validation blocks  $(date)"
    caffeinate -is .venv/bin/python host/validate_blocks.py --boards "$BOARDS" 2>&1 | tee results/validation.log
    echo "=== finished  $(date)"
else
    echo "=== SMOKE CHECK DID NOT COMPLETE - validation not started. See results/smoke.log"; exit 1
fi
